# Kyvo Website

Marketing site, command browser and Discord dashboard for the **Kyvo** bot.

Built with Next.js 15 (App Router), Tailwind CSS and TypeScript. Designed to deploy free on
[Vercel](https://vercel.com), separately from the bot.

---

## What is included

- **Landing page** — hero, feature bento grid, security spotlight, music/AI showcase, premium,
  FAQ, final CTA, footer.
- **Command library** (`/commands`) — all 516 commands extracted from the bot's real
  `cogs/commands/help.py`, searchable, filterable, with slash/prefix modes and copy-to-clipboard.
- **Dashboard** (`/dashboard`) — Discord OAuth login, guild picker (only servers where the user
  has Manage Server), server overview, read-only module preview.
- **Legal + status pages**, 404, sitemap, robots, manifest, generated Open Graph image.
- **Zero database** — the dashboard session is an encrypted, http-only cookie.

---

## Quick start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open <http://localhost:3000>.

The landing page and command library work immediately. The dashboard needs Discord OAuth values
(see below) and shows a setup screen until they are present.

---

## Environment variables

Copy `.env.example` to `.env.local` (or add the values in Vercel → Settings → Environment
Variables).

### Required for the dashboard

| Variable | What it is |
|---|---|
| `DISCORD_CLIENT_ID` | Your Discord application's Client ID |
| `DISCORD_CLIENT_SECRET` | Your Discord application's Client Secret |
| `AUTH_SECRET` | Random string used to encrypt the session cookie. Generate with `openssl rand -base64 32` |
| `NEXT_PUBLIC_SITE_URL` | Public URL, e.g. `https://kyvo.gg` — used for metadata and OAuth redirect |

### Optional

| Variable | What it does |
|---|---|
| `DISCORD_BOT_TOKEN` | Enables live member/channel/role counts and “Kyvo is here” detection |
| `NEXT_PUBLIC_INVITE_URL` | The “Add Kyvo” invite link |
| `NEXT_PUBLIC_SUPPORT_URL` | Support server invite |
| `NEXT_PUBLIC_TOPGG_URL` | Top.gg vote link |
| `NEXT_PUBLIC_PREFIX` | Prefix shown in copy (default `,`) |
| `NEXT_PUBLIC_TWITTER_URL` / `NEXT_PUBLIC_GITHUB_URL` | Optional footer social links |

### Dashboard API (live toggles)

| Variable | What it does |
|---|---|
| `DASHBOARD_API_KEY` | Shared secret for the bot-side API. Generate with `openssl rand -base64 32`. Never expose to browser. |
| `NEXT_PUBLIC_DASHBOARD_API_URL` | Public URL of the bot-side API (e.g. `https://api.kyvo.gg`). Used by the dashboard to call the API. |

> The Dashboard API is a separate FastAPI service that runs on the bot host. See **Dashboard API setup** below.

---

## Discord OAuth setup

1. Open the [Discord Developer Portal](https://discord.com/developers/applications) and select
   (or create) the Kyvo application.
2. Go to **OAuth2 → General** and copy the **Client ID** and **Client Secret** into your env.
3. Under **OAuth2 → Redirects**, add:
   - `https://your-domain.com/api/auth/callback`
   - `http://localhost:3000/api/auth/callback` (for local development)
4. Save. Restart/redeploy the site. The dashboard login button will work.

The app requests only `identify` and `guilds` — never message content.

---

## Custom domain on Vercel (free)

1. Push this folder to a Git repository (or run `vercel` from inside `website/`).
2. Import the project in Vercel. Framework preset: **Next.js**. Build command: `npm run build`.
3. In Vercel → **Settings → Domains**, add `kyvo.gg` (or your domain).
4. At your DNS provider:
   - `A` record `@` → `76.76.21.21` (Vercel's current value is shown in the dashboard)
   - `CNAME` record `www` → `cname.vercel-dns.com`
   - Or switch the nameservers to Vercel for automatic setup.
5. Wait for the certificate, then set `NEXT_PUBLIC_SITE_URL` to your final HTTPS URL and redeploy.
6. Add the same URL + `/api/auth/callback` to Discord's redirect list.

---

## Command data

`data/commands.json` is generated from the bot source:

```bash
python3 scripts/sync_commands.py
# or, from inside website/:
npm run sync:commands
```

The script reads `../cogs/commands/help.py` using Python's AST — no bot dependencies required. It
merges the bot's `MERGED_CATEGORIES`, respects `CATEGORY_ORDER`, and writes categories, groups and
command counts. Re-run it whenever you add or rename commands.

You can point it at a different checkout:

```bash
python3 scripts/sync_commands.py --help-file /path/to/cogs/commands/help.py
```

---

## Project structure

```
app/                 routes, metadata, OAuth API, legal pages
components/
  site/              landing sections, navbar, footer
  commands/          command explorer
  dashboard/         guild grid, copy button
lib/                 site config, Discord API, encrypted session, icons
data/commands.json   generated command registry
scripts/             command extractor
public/              logo
```

---

## Dashboard API setup (live toggles)

The dashboard now includes live module toggles. To enable them, run the FastAPI service on the bot host.

### 1. Install dependencies on the bot host

```bash
pip install fastapi uvicorn[standard] pydantic pydantic-settings
```

### 2. Copy the API file

Copy `dashboard_api.py` from this repo to the bot host (same directory as `main.py`).

### 3. Set environment variables on the bot host

```bash
# In the bot's .env or environment
DASHBOARD_API_KEY=your-shared-secret-here  # openssl rand -base64 32
```

### 4. Run the API (recommended: systemd)

```ini
# /etc/systemd/system/kyvo-dashboard-api.service
[Unit]
Description=Kyvo Dashboard API
After=network-online.target

[Service]
WorkingDirectory=/opt/kyvo
EnvironmentFile=/opt/kyvo/.env
ExecStart=/usr/bin/python3 dashboard_api.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now kyvo-dashboard-api
```

### 5. Expose it on your domain (free with Cloudflare Tunnel)

```bash
cloudflared tunnel --url http://localhost:8080
# Or create a named tunnel and add a CNAME: api.kyvo.gg → <tunnel-id>.cfargotunnel.com
```

### 6. Configure the website

In Vercel (or your host), add:
- `NEXT_PUBLIC_DASHBOARD_API_URL=https://api.kyvo.gg`
- `DASHBOARD_API_KEY` (same value as the bot host)

### 7. Verify

Open `/dashboard/<guild-id>` — you should see toggle switches and config forms for each module.

---

### Running locally (dev)

```bash
# Terminal 1: bot host (or same machine)
python3 dashboard_api.py

# Terminal 2: website
cd website
cp .env.example .env.local
# Add DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, AUTH_SECRET, NEXT_PUBLIC_SITE_URL
# Add NEXT_PUBLIC_DASHBOARD_API_URL=http://localhost:8080
# Add DASHBOARD_API_KEY=your-shared-secret
npm run dev
```

---

## Project structure

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Local dev server |
| `npm run build` | Production build |
| `npm run start` | Start the production server |
| `npm run sync:commands` | Regenerate `data/commands.json` from the bot |

---

## Notes

- Replace the placeholder invite/support links in `.env` before launch. The default invite contains
  `YOUR_CLIENT_ID`.
- The dashboard setup screen appears until `DISCORD_CLIENT_ID` and `DISCORD_CLIENT_SECRET` are set,
  so the site never shows a broken login button.
- No analytics or advertising scripts are included.
