const rawUrl = (value: string | undefined, fallback: string) =>
  (value || fallback).replace(/\/+$/, '');

export const site = {
  name: 'Kyvo',
  domain: 'kyvo.gg',
  url: rawUrl(process.env.NEXT_PUBLIC_SITE_URL, 'https://kyvo.gg'),
  description:
    'Kyvo is the all-in-one Discord bot for security, moderation, music, AI and community growth. Antinuke protection, automod, tickets, giveaways, leveling and 516 commands — in one place.',
  tagline: "Your server's silent guardian.",
  invite: rawUrl(
    process.env.NEXT_PUBLIC_INVITE_URL,
    'https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=8&integration_type=0&scope=bot+applications.commands',
  ),
  support: rawUrl(process.env.NEXT_PUBLIC_SUPPORT_URL, 'https://discord.com/'),
  topgg: rawUrl(process.env.NEXT_PUBLIC_TOPGG_URL, 'https://top.gg/'),
  prefix: process.env.NEXT_PUBLIC_PREFIX || ',',
  twitter: process.env.NEXT_PUBLIC_TWITTER_URL || '',
  github: process.env.NEXT_PUBLIC_GITHUB_URL || '',
};

export const navLinks = [
  { label: 'Features', href: '/#features' },
  { label: 'Security', href: '/#security' },
  { label: 'Commands', href: '/commands' },
  { label: 'Premium', href: '/#premium' },
  { label: 'Dashboard', href: '/dashboard' },
];

/** High-level numbers shown on the landing page. Update as the bot grows. */
export const highlights = [
  { label: 'Commands', value: 516, suffix: '+' },
  { label: 'Modules', value: 20, suffix: '' },
  { label: 'Anti-nuke guards', value: 12, suffix: '' },
  { label: 'Uptime', value: 24, suffix: '/7' },
];
