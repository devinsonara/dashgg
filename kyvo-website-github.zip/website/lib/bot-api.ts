import type { DiscordGuild } from '@/lib/types';

export interface ModuleConfig {
  antinuke?: { enabled: boolean };
  whitelist?: Array<Record<string, any>>;
  automod?: { enabled: boolean; punishments: Record<string, string>; ignored: Array<Record<string, any>>; logging_channel: number | null };
  autorole?: { humans: number | null; bots: number | null };
  welcome?: { enabled: boolean; channel_id: number | null; message: string | null; embed: Record<string, any> | null; auto_delete: number | null; leave_enabled: boolean; leave_channel_id: number | null; leave_message: string | null; leave_embed: Record<string, any> | null; leave_auto_delete: number | null };
  tickets?: Record<string, any>;
  leveling?: { enabled: boolean; announce_channel: number | null; style: string | null; min_xp: number; max_xp: number; cooldown: number; mode: string; voice_xp: number };
  logging?: { channels: Record<string, number> };
  giveaways?: { bonus_roles: number[] };
  premium?: { premium: boolean };
}

export interface GuildOverview {
  id: string;
  name: string;
  icon: string | null;
  memberCount: number | null;
  onlineCount: number | null;
  channelCount: number;
  roleCount: number;
  boostCount: number | null;
  boostTier: number | null;
  createdAt: string | null;
  ownerId: string | null;
  installed: boolean;
  configs: ModuleConfig;
}

const BASE = process.env.NEXT_PUBLIC_DASHBOARD_API_URL || '';
const KEY = process.env.DASHBOARD_API_KEY || '';

async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (!BASE) throw new Error('Dashboard API URL not configured');
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': KEY,
      ...(init.headers || {}),
    },
    cache: 'no-store',
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${text.slice(0, 200)}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export async function fetchGuildOverview(guildId: string): Promise<GuildOverview | null> {
  try {
    return await api<GuildOverview>(`/api/guilds/${guildId}/overview`);
  } catch {
    return null;
  }
}

export async function fetchModuleConfig(guildId: string, module: keyof ModuleConfig): Promise<any> {
  try {
    return await api<any>(`/api/guilds/${guildId}/${module}`);
  } catch {
    return null;
  }
}

export async function updateModuleConfig(guildId: string, module: string, data: any): Promise<any> {
  return await api(`/api/guilds/${guildId}/${module}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function fetchPremiumStatus(guildId: string): Promise<boolean> {
  try {
    const data = await api<{ premium: boolean }>(`/api/guilds/${guildId}/premium`);
    return data.premium;
  } catch {
    return false;
  }
}