import type { DiscordGuild, DiscordUser, GuildDetails } from './types';

const API = 'https://discord.com/api/v10';
export const MANAGE_GUILD = 1n << 5n;

export function isDiscordConfigured() {
  return Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET);
}

export function baseUrl(requestUrl: string) {
  return (process.env.NEXT_PUBLIC_SITE_URL || new URL(requestUrl).origin).replace(/\/+$/, '');
}

export function callbackUrl(requestUrl: string) {
  return `${baseUrl(requestUrl)}/api/auth/callback`;
}

export function authorizeUrl(state: string, redirectUri: string) {
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID || '',
    response_type: 'code',
    redirect_uri: redirectUri,
    scope: 'identify guilds',
    state,
  });
  return `https://discord.com/oauth2/authorize?${params.toString()}`;
}

async function discordFetch(path: string, init: RequestInit = {}) {
  const response = await fetch(`${API}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init.headers || {}),
    },
    cache: 'no-store',
  });
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(`Discord API ${response.status}: ${text.slice(0, 200)}`);
  }
  return response.json();
}

export async function exchangeCode(code: string, redirectUri: string) {
  const body = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID || '',
    client_secret: process.env.DISCORD_CLIENT_SECRET || '',
    grant_type: 'authorization_code',
    code,
    redirect_uri: redirectUri,
  });

  const response = await fetch(`${API}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    cache: 'no-store',
  });
  if (!response.ok) {
    throw new Error(`Token exchange failed (${response.status})`);
  }
  return (await response.json()) as { access_token: string; token_type: string; expires_in: number };
}

export async function fetchUser(accessToken: string): Promise<DiscordUser> {
  const user = await discordFetch('/users/@me', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  return {
    id: user.id,
    username: user.username,
    globalName: user.global_name || null,
    avatar: user.avatar || null,
  };
}

export async function fetchUserGuilds(accessToken: string): Promise<DiscordGuild[]> {
  const guilds = await discordFetch('/users/@me/guilds', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!Array.isArray(guilds)) return [];
  return guilds.map((guild: any) => ({
    id: guild.id,
    name: guild.name,
    icon: guild.icon || null,
    owner: Boolean(guild.owner),
    permissions: guild.permissions || '0',
    features: guild.features || [],
  }));
}

export function canManage(guild: DiscordGuild) {
  if (guild.owner) return true;
  try {
    return (BigInt(guild.permissions) & MANAGE_GUILD) === MANAGE_GUILD;
  } catch {
    return false;
  }
}

/** Guild IDs the bot itself is in. Returns null when no bot token is configured. */
export async function fetchBotGuildIds(): Promise<Set<string> | null> {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) return null;
  try {
    const guilds = await discordFetch('/users/@me/guilds', {
      headers: { Authorization: `Bot ${token}` },
    });
    if (!Array.isArray(guilds)) return null;
    return new Set<string>(guilds.map((guild: any) => guild.id));
  } catch {
    return null;
  }
}

export async function fetchGuildDetails(guildId: string): Promise<GuildDetails | null> {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) return null;
  const headers = { Authorization: `Bot ${token}` };
  try {
    const [guild, channels, roles] = await Promise.all([
      discordFetch(`/guilds/${guildId}?with_counts=true`, { headers }),
      discordFetch(`/guilds/${guildId}/channels`, { headers }),
      discordFetch(`/guilds/${guildId}/roles`, { headers }),
    ]);
    return {
      id: guild.id,
      name: guild.name,
      icon: guild.icon || null,
      description: guild.description || null,
      memberCount: guild.approximate_member_count ?? null,
      onlineCount: guild.approximate_presence_count ?? null,
      boostCount: guild.premium_subscription_count ?? null,
      boostTier: guild.premium_tier ?? null,
      createdAt: guild.id ? new Date(Number((BigInt(guild.id) >> 22n) + 1420070400000n)).toISOString() : null,
      channelCount: Array.isArray(channels) ? channels.length : 0,
      roleCount: Array.isArray(roles) ? roles.length : 0,
      emojiCount: Array.isArray(guild.emojis) ? guild.emojis.length : 0,
      ownerId: guild.owner_id || null,
    };
  } catch {
    return null;
  }
}
