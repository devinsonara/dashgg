export type DiscordUser = {
  id: string;
  username: string;
  globalName: string | null;
  avatar: string | null;
};

export type DiscordGuild = {
  id: string;
  name: string;
  icon: string | null;
  owner: boolean;
  permissions: string;
  features?: string[];
  memberCount?: number | null;
};

export type SessionData = {
  user: DiscordUser;
  guilds: DiscordGuild[];
  botGuildIds: string[] | null;
  createdAt: number;
};

export type CommandGroup = {
  name: string;
  commands: string[];
};

export type CommandCategory = {
  id: string;
  name: string;
  description: string;
  info: string;
  accent: number;
  icon: string;
  premium: boolean;
  count: number;
  groups: CommandGroup[];
};

export type CommandData = {
  generatedAt: string;
  totalCommands: number;
  categories: CommandCategory[];
};

export type GuildDetails = {
  id: string;
  name: string;
  icon: string | null;
  description: string | null;
  memberCount: number | null;
  onlineCount: number | null;
  boostCount: number | null;
  boostTier: number | null;
  createdAt: string | null;
  channelCount: number;
  roleCount: number;
  emojiCount: number;
  ownerId: string | null;
};
