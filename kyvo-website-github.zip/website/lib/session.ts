import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import type { NextResponse } from 'next/server';
import type { SessionData } from './types';

export const SESSION_COOKIE = 'kyvo_session';
export const STATE_COOKIE = 'kyvo_oauth_state';
const MAX_AGE = 60 * 60 * 24 * 7;

function secret() {
  const value =
    process.env.AUTH_SECRET ||
    process.env.DISCORD_CLIENT_SECRET ||
    'kyvo-development-secret-change-me';
  return crypto.createHash('sha256').update(value).digest();
}

function b64url(buf: Buffer) {
  return buf.toString('base64url');
}

export function encodeSession(data: SessionData) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', secret(), iv);
  const payload = Buffer.concat([cipher.update(JSON.stringify(data), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, payload]).toString('base64url');
}

export function decodeSession(token: string | undefined | null): SessionData | null {
  if (!token) return null;
  try {
    const raw = Buffer.from(token, 'base64url');
    const iv = raw.subarray(0, 12);
    const tag = raw.subarray(12, 28);
    const payload = raw.subarray(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', secret(), iv);
    decipher.setAuthTag(tag);
    const json = Buffer.concat([decipher.update(payload), decipher.final()]).toString('utf8');
    const data = JSON.parse(json) as SessionData;
    if (!data?.user?.id || !Array.isArray(data.guilds)) return null;
    if (!data.createdAt || Date.now() - data.createdAt > MAX_AGE * 1000) return null;
    return data;
  } catch {
    return null;
  }
}

export async function getSession() {
  const store = await cookies();
  return decodeSession(store.get(SESSION_COOKIE)?.value);
}

export function setSessionCookie(response: NextResponse, data: SessionData) {
  response.cookies.set({
    name: SESSION_COOKIE,
    value: encodeSession(data),
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: MAX_AGE,
  });
}

export function clearSessionCookie(response: NextResponse) {
  response.cookies.set({
    name: SESSION_COOKIE,
    value: '',
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 0,
  });
}

export function newState() {
  return b64url(crypto.randomBytes(24));
}
