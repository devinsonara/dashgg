import raw from '@/data/commands.json';
import type { CommandCategory, CommandData } from './types';

export const commandData = raw as unknown as CommandData;

export const categories: CommandCategory[] = commandData.categories;

export const totalCommands = commandData.totalCommands;

export const premiumCategory = categories.find((category) => category.premium);

export function getCategory(id: string) {
  return categories.find((category) => category.id === id);
}

export function commandLabel(command: string, mode: 'slash' | 'prefix') {
  return mode === 'slash' ? `/${command}` : `,${command}`;
}
