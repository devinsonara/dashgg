export function guildIconUrl(guildId: string, hash: string | null, size = 128) {
  if (!hash) return null;
  const extension = hash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/icons/${guildId}/${hash}.${extension}?size=${size}`;
}

export function userAvatarUrl(userId: string, hash: string | null, size = 128) {
  if (!hash) return null;
  const extension = hash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/avatars/${userId}/${hash}.${extension}?size=${size}`;
}
