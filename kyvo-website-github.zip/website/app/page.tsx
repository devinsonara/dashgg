import { Hero } from '@/components/site/hero';
import { TrustStrip } from '@/components/site/trust-strip';
import { Features } from '@/components/site/features';
import { Security } from '@/components/site/security';
import { Showcase } from '@/components/site/showcase';
import { CommandPreview } from '@/components/site/command-preview';
import { Premium } from '@/components/site/premium';
import { FAQ } from '@/components/site/faq';
import { CTA } from '@/components/site/cta';
import { categories, totalCommands } from '@/lib/commands';

export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustStrip />
      <Features />
      <Security />
      <Showcase />
      <CommandPreview categories={categories} total={totalCommands} />
      <Premium />
      <FAQ />
      <CTA />
    </>
  );
}
