import type { Metadata } from 'next';
import { CommandExplorer } from '@/components/commands/command-explorer';
import { categories, commandData, totalCommands } from '@/lib/commands';
import { Sparkles } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Commands',
  description: `Search all ${totalCommands} Kyvo commands across ${categories.length} categories — security, moderation, automod, tickets, giveaways, leveling, music, AI and more.`,
};

export default function CommandsPage() {
  return (
    <>
      <section className="relative overflow-hidden pb-10 pt-32 sm:pt-36">
        <div className="container-page">
          <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
            <div className="max-w-2xl">
              <p className="eyebrow">
                <Sparkles className="h-3.5 w-3.5 text-amber" />
                Command library
              </p>
              <h1 className="mt-5 text-4xl font-extrabold tracking-[-0.04em] text-white sm:text-5xl">
                Every command.
                <br />
                <span className="text-gradient">One clean library.</span>
              </h1>
              <p className="mt-4 max-w-xl text-[15px] leading-7 text-zinc-400">
                Search {totalCommands} commands across {categories.length} categories. Click any
                command to copy it, then paste it straight into Discord.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3 sm:gap-4">
              {[
                { value: totalCommands, label: 'Commands' },
                { value: categories.length, label: 'Categories' },
                { value: '2', label: 'Input modes' },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-2xl border border-white/[0.08] bg-white/[0.025] px-4 py-3 text-center"
                >
                  <p className="text-xl font-bold text-white">{stat.value}</p>
                  <p className="mt-0.5 text-[9.5px] uppercase tracking-[0.14em] text-zinc-500">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <CommandExplorer
        categories={categories}
        total={totalCommands}
        generatedAt={commandData.generatedAt}
      />
    </>
  );
}
