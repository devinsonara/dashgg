import type { MetadataRoute } from 'next';
import { site } from '@/lib/site';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Kyvo',
    short_name: 'Kyvo',
    description: site.description,
    start_url: '/',
    display: 'standalone',
    background_color: '#070709',
    theme_color: '#FFB43C',
    icons: [
      {
        src: '/logo.svg',
        sizes: 'any',
        type: 'image/svg+xml',
      },
    ],
  };
}
