import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, FileText } from 'lucide-react';
import { site } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Terms of service',
  description: 'The rules for using Kyvo in your Discord server and on this website.',
};

const sections = [
  {
    title: 'Using Kyvo',
    body: 'You may add Kyvo to servers you manage and use its commands in line with Discord’s Terms of Service and Community Guidelines. You are responsible for how the bot is configured in your server.',
  },
  {
    title: 'Acceptable use',
    body: 'Do not use Kyvo to raid, harass, spy on members, bypass Discord limits, or process illegal content. We may remove access from servers that abuse the bot or threaten other communities.',
  },
  {
    title: 'Premium',
    body: 'Premium features are activated with a redeem code. Codes are non-transferable unless stated otherwise. Abuse, resale or attempts to bypass premium checks can result in removal without refund.',
  },
  {
    title: 'Availability',
    body: 'Kyvo is provided as-is. We aim for high uptime but cannot guarantee uninterrupted service, and features may change as the bot evolves. Planned maintenance is announced in the support server where possible.',
  },
  {
    title: 'Your content',
    body: 'You keep ownership of the messages, images and configuration you provide. You grant Kyvo permission to store and process that content only as needed to run the features you enable.',
  },
  {
    title: 'Liability',
    body: 'To the maximum extent permitted by law, Kyvo and its maintainers are not liable for indirect or consequential damages, data loss, or moderation actions taken by server staff. Back up important server configuration before major changes.',
  },
  {
    title: 'Changes',
    body: 'These terms may be updated as the bot changes. Continued use after an update means you accept the revised terms. Material changes will be announced in the support server.',
  },
];

export default function TermsPage() {
  return (
    <section className="relative pb-24 pt-32 sm:pt-36">
      <div className="container-page max-w-3xl">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-[11.5px] text-zinc-500 transition hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back home
        </Link>
        <p className="eyebrow mt-6">
          <FileText className="h-3.5 w-3.5 text-amber" />
          Legal
        </p>
        <h1 className="mt-4 text-4xl font-extrabold tracking-[-0.035em] text-white sm:text-5xl">
          Terms of service
        </h1>
        <p className="mt-3 text-[13px] text-zinc-500">Last updated: November 23, 2026</p>

        <div className="mt-10 space-y-7">
          {sections.map((section, index) => (
            <div key={section.title}>
              <h2 className="flex items-center gap-2 text-lg font-semibold tracking-[-0.01em] text-white">
                <span className="font-mono text-[11px] text-amber/60">
                  {String(index + 1).padStart(2, '0')}
                </span>
                {section.title}
              </h2>
              <p className="mt-2 text-[13.5px] leading-7 text-zinc-400">{section.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5 text-[12.5px] leading-6 text-zinc-500">
          Need clarification? Ask in the{' '}
          <a href={site.support} className="text-amber underline decoration-amber/30 underline-offset-4">
            support server
          </a>
          .
        </div>
      </div>
    </section>
  );
}
