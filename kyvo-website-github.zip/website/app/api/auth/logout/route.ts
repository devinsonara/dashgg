import { NextResponse, type NextRequest } from 'next/server';
import { clearSessionCookie, STATE_COOKIE } from '@/lib/session';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const response = NextResponse.redirect(new URL('/', request.url));
  clearSessionCookie(response);
  response.cookies.set({
    name: STATE_COOKIE,
    value: '',
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 0,
  });
  return response;
}
