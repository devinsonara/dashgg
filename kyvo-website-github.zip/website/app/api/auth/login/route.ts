import { NextResponse, type NextRequest } from 'next/server';
import { authorizeUrl, callbackUrl, isDiscordConfigured } from '@/lib/discord';
import { newState, STATE_COOKIE } from '@/lib/session';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  if (!isDiscordConfigured()) {
    return NextResponse.redirect(new URL('/dashboard?error=not-configured', request.url));
  }

  const state = newState();
  const redirectUri = callbackUrl(request.url);
  const response = NextResponse.redirect(authorizeUrl(state, redirectUri));

  response.cookies.set({
    name: STATE_COOKIE,
    value: state,
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 10,
  });

  return response;
}
