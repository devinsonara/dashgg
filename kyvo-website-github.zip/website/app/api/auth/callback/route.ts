import { NextResponse, type NextRequest } from 'next/server';
import {
  callbackUrl,
  canManage,
  exchangeCode,
  fetchBotGuildIds,
  fetchUser,
  fetchUserGuilds,
} from '@/lib/discord';
import { setSessionCookie, STATE_COOKIE } from '@/lib/session';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const expectedState = request.cookies.get(STATE_COOKIE)?.value;

  if (!code || !state || !expectedState || state !== expectedState) {
    return NextResponse.redirect(new URL('/dashboard?error=state', request.url));
  }

  try {
    const redirectUri = callbackUrl(request.url);
    const token = await exchangeCode(code, redirectUri);
    const [user, guilds, botGuildIds] = await Promise.all([
      fetchUser(token.access_token),
      fetchUserGuilds(token.access_token),
      fetchBotGuildIds(),
    ]);

    const manageable = guilds
      .filter(canManage)
      .map((guild) => ({
        id: guild.id,
        name: guild.name,
        icon: guild.icon,
        owner: guild.owner,
        permissions: guild.permissions,
        memberCount: null,
      }))
      .sort((a, b) => Number(b.owner) - Number(a.owner) || a.name.localeCompare(b.name))
      // Keep the encrypted cookie comfortably below the 4 KB browser limit.
      .slice(0, 40);

    const manageableIds = new Set(manageable.map((guild) => guild.id));
    const detectedBotGuilds = botGuildIds
      ? [...botGuildIds].filter((id) => manageableIds.has(id))
      : null;

    const response = NextResponse.redirect(new URL('/dashboard', request.url));
    setSessionCookie(response, {
      user,
      guilds: manageable,
      botGuildIds: detectedBotGuilds,
      createdAt: Date.now(),
    });
    response.cookies.set({
      name: STATE_COOKIE,
      value: '',
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      path: '/',
      maxAge: 0,
    });

    return response;
  } catch (error) {
    console.error('[kyvo] Discord auth failed:', error);
    return NextResponse.redirect(new URL('/dashboard?error=auth', request.url));
  }
}
