import type { Metadata } from 'next';
import Link from 'next/link';
import {
  ArrowRight,
  Check,
  CircleHelp,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  ShieldCheck,
  Sparkles,
  Terminal,
  UserRound,
  type LucideIcon,
} from 'lucide-react';
import { Logo } from '@/components/logo';
import { DiscordIcon } from '@/components/discord-icon';
import { GuildGrid } from '@/components/dashboard/guild-grid';
import { isDiscordConfigured } from '@/lib/discord';
import { getSession } from '@/lib/session';
import { userAvatarUrl } from '@/lib/avatar';
import { initials } from '@/lib/utils';
import { site } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Dashboard',
  description: 'Sign in with Discord to review the servers you manage with Kyvo.',
};

const errors: Record<string, string> = {
  'not-configured': 'Discord OAuth is not configured yet. Add your client ID and secret to the environment.',
  state: 'Your login session expired. Please try again.',
  auth: 'We could not complete the Discord login. Please try again.',
};

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;
  const configured = isDiscordConfigured();
  const session = await getSession();
  const error = params.error ? errors[params.error] : null;

  if (!configured) {
    return <SetupScreen />;
  }

  if (!session) {
    return <LoginScreen error={error} />;
  }

  const { user, guilds, botGuildIds } = session;
  const avatar = userAvatarUrl(user.id, user.avatar, 128);
  const name = user.globalName || user.username;
  const installed = botGuildIds
    ? guilds.filter((guild) => botGuildIds.includes(guild.id)).length
    : null;

  return (
    <section className="relative pb-24 pt-32 sm:pt-36">
      <div className="container-page">
        <div className="flex flex-col gap-5 border-b border-white/[0.07] pb-8 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            {avatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={avatar}
                alt=""
                width={56}
                height={56}
                className="h-14 w-14 rounded-2xl border border-white/10 object-cover"
              />
            ) : (
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-amber/30 to-amber/5 text-lg font-bold text-amber">
                {initials(name)}
              </span>
            )}
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-amber">
                Dashboard
              </p>
              <h1 className="mt-0.5 text-2xl font-bold tracking-[-0.02em] text-white sm:text-3xl">
                Welcome back, {name}
              </h1>
              <p className="mt-1 text-[12px] text-zinc-500">
                @{user.username} · signed in with Discord
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a href="/api/auth/logout" className="btn-ghost !px-4 !py-2 text-[12px]">
              <LogOut className="h-3.5 w-3.5" />
              Log out
            </a>
            <a href={site.invite} target="_blank" rel="noreferrer" className="btn-primary !px-4 !py-2 text-[12px]">
              Add Kyvo
              <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>

        {error && (
          <div className="mt-6 rounded-2xl border border-danger/20 bg-danger/[0.06] px-4 py-3 text-[12.5px] text-danger/90">
            {error}
          </div>
        )}

        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Servers managed" value={guilds.length} icon={LayoutDashboard} />
          <StatCard
            label="Kyvo installed"
            value={installed == null ? '—' : installed}
            icon={ShieldCheck}
            hint={installed == null ? 'Add a bot token to detect' : undefined}
          />
          <StatCard label="Plan" value="Free" icon={Sparkles} hint="Premium available in Discord" />
          <StatCard label="Mode" value="Read-only" icon={LockKeyhole} hint="Live toggles coming next" />
        </div>

        <div className="mt-6 flex flex-col gap-3 rounded-2xl border border-amber/20 bg-amber/[0.05] px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="flex items-start gap-2 text-[12px] leading-5 text-amber-soft/90">
            <CircleHelp className="mt-0.5 h-4 w-4 shrink-0" />
            This is the read-only dashboard preview. Server settings are still managed in Discord
            while live toggles are being built.
          </p>
          <a
            href={site.support}
            target="_blank"
            rel="noreferrer"
            className="shrink-0 text-[11.5px] font-medium text-amber underline decoration-amber/30 underline-offset-4 hover:text-amber-soft"
          >
            What&apos;s next?
          </a>
        </div>

        <div className="mt-10">
          <GuildGrid guilds={guilds} botGuildIds={botGuildIds} />
        </div>

        <div className="mt-10 grid gap-3 sm:grid-cols-2">
          <div className="card flex items-start gap-3 p-5">
            <span className="icon-tile h-10 w-10 rounded-xl">
              <UserRound className="h-4 w-4" />
            </span>
            <div>
              <h2 className="text-[13.5px] font-semibold text-white">Only manageable servers</h2>
              <p className="mt-1 text-[12px] leading-5 text-zinc-500">
                We only list servers where you have Manage Server or owner permissions. Nothing else
                is shown or stored.
              </p>
            </div>
          </div>
          <div className="card flex items-start gap-3 p-5">
            <span className="icon-tile h-10 w-10 rounded-xl">
              <LockKeyhole className="h-4 w-4" />
            </span>
            <div>
              <h2 className="text-[13.5px] font-semibold text-white">Encrypted session</h2>
              <p className="mt-1 text-[12px] leading-5 text-zinc-500">
                Your Discord profile and server list live in an encrypted, http-only cookie. Signing
                out clears it instantly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
  hint,
}: {
  label: string;
  value: string | number;
  icon: LucideIcon;
  hint?: string;
}) {
  return (
    <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-zinc-500">{label}</p>
        <Icon className="h-4 w-4 text-amber/70" />
      </div>
      <p className="mt-2 text-xl font-bold text-white">{value}</p>
      {hint && <p className="mt-0.5 text-[9.5px] text-zinc-600">{hint}</p>}
    </div>
  );
}

function LoginScreen({ error }: { error: string | null }) {
  return (
    <section className="relative pb-24 pt-32 sm:pt-36">
      <div className="container-page">
        <div className="mx-auto max-w-xl">
          <div className="text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl border border-amber/25 bg-amber/10 shadow-glow-sm">
              <Logo withWordmark={false} className="!gap-0 [&>svg]:h-10 [&>svg]:w-10" />
            </div>
            <p className="mt-6 inline-flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-zinc-500">
              <LockKeyhole className="h-3 w-3 text-amber" />
              Read-only preview
            </p>
            <h1 className="mt-4 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl">
              Your servers, <span className="text-gradient">in one place.</span>
            </h1>
            <p className="mx-auto mt-3 max-w-md text-[14px] leading-6 text-zinc-400">
              Sign in with Discord to see the servers you manage, check whether Kyvo is installed,
              and review the overview. No message access, ever.
            </p>
          </div>

          {error && (
            <div className="mt-6 rounded-2xl border border-danger/20 bg-danger/[0.06] px-4 py-3 text-center text-[12.5px] text-danger/90">
              {error}
            </div>
          )}

          <div className="card mt-7 p-5 sm:p-6">
            <a href="/api/auth/login" className="btn-primary w-full !py-3 text-[13px]">
              <DiscordIcon className="h-4 w-4" />
              Continue with Discord
            </a>
            <p className="mt-3 text-center text-[10.5px] leading-5 text-zinc-600">
              Requests <span className="text-zinc-400">identify</span> and{' '}
              <span className="text-zinc-400">guilds</span>. We never request the message content
              scope.
            </p>

            <div className="mt-5 space-y-2.5 border-t border-white/[0.06] pt-5">
              {[
                'Only servers where you have Manage Server',
                'Encrypted, http-only session cookie',
                'Sign out clears the session immediately',
              ].map((item) => (
                <p key={item} className="flex items-center gap-2 text-[12px] text-zinc-400">
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-mint/10">
                    <Check className="h-2.5 w-2.5 text-mint" />
                  </span>
                  {item}
                </p>
              ))}
            </div>
          </div>

          <p className="mt-5 text-center text-[11px] text-zinc-600">
            By continuing you agree to the{' '}
            <Link href="/terms" className="text-zinc-400 underline decoration-white/20 underline-offset-4">
              terms
            </Link>{' '}
            and{' '}
            <Link href="/privacy" className="text-zinc-400 underline decoration-white/20 underline-offset-4">
              privacy policy
            </Link>
            .
          </p>
        </div>
      </div>
    </section>
  );
}

function SetupScreen() {
  const steps = [
    {
      title: 'Create a Discord application',
      copy: 'Open the Developer Portal, create an app, and copy the Client ID and Client Secret into your environment.',
      code: 'DISCORD_CLIENT_ID=...\nDISCORD_CLIENT_SECRET=...',
    },
    {
      title: 'Add the redirect URI',
      copy: 'In OAuth2 → Redirects, add the callback URL for your domain (and localhost while developing).',
      code: `${site.url}/api/auth/callback\nhttp://localhost:3000/api/auth/callback`,
    },
    {
      title: 'Set a session secret',
      copy: 'Generate a long random value for AUTH_SECRET. Optionally add a bot token to unlock live server stats.',
      code: 'AUTH_SECRET=...\nDISCORD_BOT_TOKEN=...',
    },
  ];

  return (
    <section className="relative pb-24 pt-32 sm:pt-36">
      <div className="container-page">
        <div className="mx-auto max-w-2xl">
          <div className="text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-amber/25 bg-amber/10 text-amber">
              <Terminal className="h-6 w-6" />
            </div>
            <p className="mt-5 eyebrow">Dashboard setup</p>
            <h1 className="mt-4 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl">
              Connect Discord to <span className="text-gradient">unlock the dashboard.</span>
            </h1>
            <p className="mx-auto mt-3 max-w-lg text-[14px] leading-6 text-zinc-400">
              The marketing site and command library work right now. The dashboard needs three
              environment values to talk to Discord.
            </p>
          </div>

          <div className="mt-8 space-y-3">
            {steps.map((step, index) => (
              <div key={step.title} className="card p-5">
                <div className="flex items-start gap-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-amber/25 bg-amber/10 font-mono text-[11px] font-semibold text-amber">
                    {index + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h2 className="text-[13.5px] font-semibold text-white">{step.title}</h2>
                    <p className="mt-1 text-[12px] leading-5 text-zinc-500">{step.copy}</p>
                    <pre className="mt-3 overflow-x-auto rounded-xl border border-white/[0.07] bg-black/40 p-3 font-mono text-[11px] leading-5 text-zinc-300">
                      {step.code}
                    </pre>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-5 rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4 text-[11.5px] leading-5 text-zinc-500">
            <p className="flex items-start gap-2">
              <CircleHelp className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber" />
              After saving the values, redeploy the site. The login button will appear automatically
              and the dashboard will work with your own Discord app.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Link href="/commands" className="btn-ghost !px-4 !py-2 text-[12px]">
              Browse commands instead
            </Link>
            <a href={site.support} target="_blank" rel="noreferrer" className="btn-primary !px-4 !py-2 text-[12px]">
              Get help
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
