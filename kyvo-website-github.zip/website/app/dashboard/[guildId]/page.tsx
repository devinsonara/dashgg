import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import {
  ArrowLeft,
  ArrowUpRight,
  CalendarDays,
  Gift,
  Hash,
  LockKeyhole,
  Music2,
  ScrollText,
  ShieldCheck,
  Sparkles,
  Ticket,
  TrendingUp,
  UserCheck,
  Users,
  Zap,
} from 'lucide-react';
import { CopyIdButton } from '@/components/dashboard/copy-id-button';
import { ModuleManager } from '@/components/dashboard/module-manager';
import { canManage, fetchGuildDetails } from '@/lib/discord';
import { getSession } from '@/lib/session';
import { guildIconUrl } from '@/lib/avatar';
import { formatDate, formatFullNumber, initials } from '@/lib/utils';
import { site } from '@/lib/site';
import { cn } from '@/lib/utils';
import { fetchGuildOverview, fetchPremiumStatus } from '@/lib/bot-api';

export const metadata: Metadata = {
  title: 'Server overview',
};

const protections = [
  'Anti-ban & anti-kick',
  'Anti-webhook creation',
  'Anti-bot add',
  'Anti-channel delete',
  'Anti-role delete',
  'Anti-raid',
  'Emergency lockdown',
  'Whitelist & trusted users',
];

export default async function GuildPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session = await getSession();

  if (!session) redirect('/dashboard');

  const guild = session.guilds.find((item) => item.id === guildId);
  if (!guild || !canManage(guild)) notFound();

  const details = await fetchGuildDetails(guildId);
  const overview = await fetchGuildOverview(guildId);
  const icon = guildIconUrl(guildId, details?.icon ?? guild.icon, 256);
  const installed = session.botGuildIds ? session.botGuildIds.includes(guildId) : null;
  const premium = overview?.configs.premium?.premium ?? false;

  const stats = [
    { label: 'Members', value: formatFullNumber(details?.memberCount ?? null), icon: Users },
    { label: 'Online', value: formatFullNumber(details?.onlineCount ?? null), icon: Zap },
    { label: 'Channels', value: formatFullNumber(details?.channelCount ?? null), icon: Hash },
    { label: 'Roles', value: formatFullNumber(details?.roleCount ?? null), icon: LockKeyhole },
    { label: 'Boosts', value: formatFullNumber(details?.boostCount ?? null), icon: Sparkles },
    { label: 'Created', value: formatDate(details?.createdAt ?? null), icon: CalendarDays },
  ];

  return (
    <section className="relative pb-24 pt-28 sm:pt-32">
      <div className="container-page">
        <Link
          href="/dashboard"
          className="inline-flex items-center gap-1.5 text-[11.5px] text-zinc-500 transition hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to dashboard
        </Link>

        <div className="mt-5 overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-b from-white/[0.045] to-transparent">
          <div className="relative p-5 sm:p-7">
            <div aria-hidden className="absolute inset-0 grid-bg opacity-20" />
            <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                {icon ? (
                  <img src={icon} alt="" width={64} height={64} className="h-16 w-16 rounded-2xl border border-white/10 object-cover" />
                ) : (
                  <span className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-amber/30 to-amber/5 text-lg font-bold text-amber">
                    {initials(details?.name || guild.name)}
                  </span>
                )}
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="text-2xl font-bold tracking-[-0.02em] text-white sm:text-3xl">
                      {details?.name || guild.name}
                    </h1>
                    {guild.owner && (
                      <span className="rounded-md border border-amber/20 bg-amber/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-amber">
                        Owner
                      </span>
                    )}
                    {installed === true && (
                      <span className="inline-flex items-center gap-1 rounded-md border border-mint/20 bg-mint/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-mint">
                        <ShieldCheck className="h-2.5 w-2.5" />
                        Kyvo installed
                      </span>
                    )}
                    {premium && (
                      <span className="inline-flex items-center gap-1 rounded-md border border-amber/20 bg-amber/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-amber">
                        <Sparkles className="h-2.5 w-2.5" />
                        Premium
                      </span>
                    )}
                  </div>
                  <p className="mt-1 font-mono text-[10px] text-zinc-600">ID {guildId}</p>
                  {details?.description && (
                    <p className="mt-2 max-w-2xl text-[12.5px] leading-5 text-zinc-500">
                      {details.description}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <CopyIdButton value={guildId} />
                <a
                  href={`https://discord.com/channels/${guildId}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-xl border border-amber/25 bg-amber/10 px-3 py-2 text-[11.5px] font-medium text-amber transition hover:bg-amber/15"
                >
                  Open Discord
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-px border-t border-white/[0.07] bg-white/[0.07] sm:grid-cols-3 lg:grid-cols-6">
            {stats.map((stat) => (
              <div key={stat.label} className="bg-ink-950/90 px-4 py-4">
                <p className="flex items-center gap-1.5 text-[9.5px] uppercase tracking-[0.14em] text-zinc-600">
                  <stat.icon className="h-3 w-3 text-amber/60" />
                  {stat.label}
                </p>
                <p className="mt-1.5 text-[15px] font-semibold text-white">{stat.value}</p>
              </div>
            ))}
          </div>
        </div>

        {!details && (
          <div className={cn(
            'mt-4 flex flex-col gap-3 rounded-2xl border px-4 py-3 sm:flex-row sm:items-center sm:justify-between',
            installed === false
              ? 'border-amber/20 bg-amber/[0.05]'
              : 'border-white/[0.08] bg-white/[0.02]',
          )}
          >
            <div className="flex items-start gap-2">
              <LockKeyhole className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
              <p className="text-[12px] leading-5 text-zinc-400">
                {installed === false
                  ? 'Kyvo is not installed in this server yet. Add it to start protecting and managing it.'
                  : 'Live member, channel and role counts are locked. Add DISCORD_BOT_TOKEN to the environment to unlock them.'}
              </p>
            </div>
            <a
              href={site.invite}
              target="_blank"
              rel="noreferrer"
              className="btn-primary shrink-0 !px-4 !py-2 text-[11.5px]"
            >
              {installed === false ? 'Add Kyvo' : 'Invite Kyvo'}
              <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          </div>
        )}

        <ModuleManager
          guildId={guildId}
          installed={installed === true}
          premium={premium}
          initialConfigs={overview?.configs || {}}
        />

        <div className="mt-10 grid gap-3 sm:grid-cols-2">
          <div className="card flex items-start gap-3 p-5">
            <span className="icon-tile h-10 w-10 rounded-xl">
              <UserCheck className="h-4 w-4" />
            </span>
            <div>
              <h2 className="text-[13.5px] font-semibold text-white">Only manageable servers</h2>
              <p className="mt-1 text-[12px] leading-5 text-zinc-500">
                We only list servers where you have Manage Server or owner permissions. Nothing else
                is shown or stored.
              </p>
            </div>
          </div>
          <div className="card flex items-start gap-3 p-5">
            <span className="icon-tile h-10 w-10 rounded-xl">
              <LockKeyhole className="h-4 w-4" />
            </span>
            <div>
              <h2 className="text-[13.5px] font-semibold text-white">Encrypted session</h2>
              <p className="mt-1 text-[12px] leading-5 text-zinc-500">
                Your Discord profile and server list live in an encrypted, http-only cookie. Signing
                out clears it instantly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}