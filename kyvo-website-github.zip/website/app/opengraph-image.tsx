import { ImageResponse } from 'next/og';
import { site } from '@/lib/site';

export const alt = 'Kyvo — Your server’s silent guardian';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          padding: '72px',
          background: 'linear-gradient(135deg, #070709 0%, #0d0b08 55%, #1a1206 100%)',
          color: '#ffffff',
          fontFamily: 'sans-serif',
          position: 'relative',
        }}
      >
        <div
          style={{
            position: 'absolute',
            top: '-220px',
            right: '-160px',
            width: '620px',
            height: '620px',
            borderRadius: '999px',
            background: 'radial-gradient(circle, rgba(255,180,60,.28), transparent 70%)',
            display: 'flex',
          }}
        />
        <div
          style={{
            position: 'absolute',
            bottom: '-260px',
            left: '-120px',
            width: '560px',
            height: '560px',
            borderRadius: '999px',
            background: 'radial-gradient(circle, rgba(255,180,60,.12), transparent 70%)',
            display: 'flex',
          }}
        />

        <div style={{ display: 'flex', alignItems: 'center', gap: '18px' }}>
          <div
            style={{
              width: '74px',
              height: '74px',
              borderRadius: '22px',
              background: 'linear-gradient(135deg, #FFD08A, #FFB43C 50%, #E8951B)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#0A0A0D',
              fontSize: '46px',
              fontWeight: 900,
            }}
          >
            K
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ fontSize: '34px', fontWeight: 800, letterSpacing: '-1px' }}>Kyvo</div>
            <div style={{ fontSize: '17px', color: '#a1a1aa' }}>{site.domain}</div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ fontSize: '76px', fontWeight: 900, letterSpacing: '-4px', lineHeight: 1 }}>
            Your server&apos;s
          </div>
          <div
            style={{
              fontSize: '76px',
              fontWeight: 900,
              letterSpacing: '-4px',
              lineHeight: 1,
              color: '#FFB43C',
            }}
          >
            silent guardian.
          </div>
          <div style={{ fontSize: '24px', color: '#a1a1aa', maxWidth: '820px', lineHeight: 1.4 }}>
            516 commands · antinuke · automod · music · AI · tickets · giveaways · leveling
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '28px', fontSize: '19px', color: '#d4d4d8' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '99px', background: '#2ECC71' }} />
            All systems operational
          </div>
          <div style={{ color: '#52525b' }}>•</div>
          <div>Security first. Always.</div>
          <div style={{ color: '#52525b' }}>•</div>
          <div>Free core features</div>
        </div>
      </div>
    ),
    { ...size },
  );
}
