import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Navbar } from '@/components/site/navbar';
import { Footer } from '@/components/site/footer';
import { site } from '@/lib/site';

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: 'Kyvo — Your server\u2019s silent guardian',
    template: '%s — Kyvo',
  },
  description: site.description,
  applicationName: 'Kyvo',
  keywords: [
    'Kyvo',
    'Discord bot',
    'antinuke',
    'automod',
    'Discord moderation',
    'Discord music bot',
    'Discord tickets',
    'Discord giveaways',
    'Discord leveling',
  ],
  authors: [{ name: 'Kyvo' }],
  creator: 'Kyvo',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: site.url,
    siteName: 'Kyvo',
    title: 'Kyvo — Your server\u2019s silent guardian',
    description: site.description,
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Kyvo — Your server\u2019s silent guardian',
    description: site.description,
  },
  icons: {
    icon: '/logo.svg',
    shortcut: '/logo.svg',
    apple: '/logo.svg',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: '#070709',
  colorScheme: 'dark',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="relative min-h-screen font-sans">
        <noscript>
          <style>{'.reveal{opacity:1!important;transform:none!important}'}</style>
        </noscript>
        <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute inset-0 grid-bg opacity-[0.55] mask-radial" />
          <div className="absolute left-1/2 top-[-22rem] h-[42rem] w-[62rem] -translate-x-1/2 rounded-full bg-amber/[0.10] blur-[130px]" />
          <div className="absolute right-[-14rem] top-[38rem] h-[32rem] w-[32rem] rounded-full bg-amber/[0.05] blur-[120px]" />
          <div className="absolute bottom-0 left-[-12rem] h-[26rem] w-[26rem] rounded-full bg-[#2a1a05]/50 blur-[120px]" />
        </div>

        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-amber focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-ink-950"
        >
          Skip to content
        </a>

        <Navbar />
        <main id="main">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
