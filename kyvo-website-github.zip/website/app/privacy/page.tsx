import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { site } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Privacy policy',
  description: 'How Kyvo handles data from Discord, the dashboard and the website.',
};

const sections = [
  {
    title: 'What we collect',
    body: [
      'When you sign in to the dashboard, Discord shares your user ID, username, display name, avatar, and the list of servers you belong to. We filter that list to servers where you have Manage Server or owner permissions.',
      'We never request the message content scope. The website does not read, store or sell your messages.',
    ],
  },
  {
    title: 'What the bot stores',
    body: [
      'Server configuration — such as antinuke settings, automod rules, welcome messages, ticket panels, leveling data and premium status — is stored in the bot’s own database so features keep working across restarts.',
      'Temporary game state, snipes and transcripts are kept only as long as the related feature needs them.',
    ],
  },
  {
    title: 'How the dashboard works',
    body: [
      'The dashboard stores your Discord profile and manageable server list inside an encrypted, http-only session cookie. The cookie is signed with a server-side secret and cannot be read by browser scripts.',
      'Signing out clears the cookie immediately. The session expires automatically after seven days.',
    ],
  },
  {
    title: 'Third parties',
    body: [
      'The dashboard talks to the Discord API to complete sign-in and read server metadata. The marketing site uses no advertising trackers and no third-party analytics scripts by default.',
      'If you deploy the site with your own analytics or hosting provider, their policies apply in addition to this page.',
    ],
  },
  {
    title: 'Your choices',
    body: [
      'You can sign out at any time, remove Kyvo from a server, or ask in the support server to have server configuration deleted. Removing the bot stops all further data collection for that server.',
    ],
  },
];

export default function PrivacyPage() {
  return (
    <section className="relative pb-24 pt-32 sm:pt-36">
      <div className="container-page max-w-3xl">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-[11.5px] text-zinc-500 transition hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back home
        </Link>
        <p className="eyebrow mt-6">
          <ShieldCheck className="h-3.5 w-3.5 text-amber" />
          Legal
        </p>
        <h1 className="mt-4 text-4xl font-extrabold tracking-[-0.035em] text-white sm:text-5xl">
          Privacy policy
        </h1>
        <p className="mt-3 text-[13px] text-zinc-500">Last updated: November 23, 2026</p>

        <div className="mt-10 space-y-8">
          {sections.map((section) => (
            <div key={section.title}>
              <h2 className="text-lg font-semibold tracking-[-0.01em] text-white">{section.title}</h2>
              <div className="mt-2 space-y-3">
                {section.body.map((paragraph) => (
                  <p key={paragraph} className="text-[13.5px] leading-7 text-zinc-400">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5 text-[12.5px] leading-6 text-zinc-500">
          Questions about privacy? Join the support server at{' '}
          <a href={site.support} className="text-amber underline decoration-amber/30 underline-offset-4">
            {site.support.replace(/^https?:\/\//, '')}
          </a>{' '}
          and ask for the team.
        </div>
      </div>
    </section>
  );
}
