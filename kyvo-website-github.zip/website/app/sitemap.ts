import type { MetadataRoute } from 'next';
import { site } from '@/lib/site';

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const routes = ['', '/commands', '/dashboard', '/privacy', '/terms', '/status'];
  return routes.map((route) => {
    const changeFrequency: 'weekly' | 'monthly' =
      route === '' || route === '/commands' ? 'weekly' : 'monthly';
    return {
      url: `${site.url}${route}`,
      lastModified: now,
      changeFrequency,
      priority: route === '' ? 1 : route === '/commands' ? 0.9 : 0.5,
    };
  });
}
