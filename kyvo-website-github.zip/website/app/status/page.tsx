import type { Metadata } from 'next';
import Link from 'next/link';
import { Activity, ArrowLeft, Check, Radio, Server, ShieldCheck } from 'lucide-react';
import { site } from '@/lib/site';

export const metadata: Metadata = {
  title: 'Status',
  description: 'Current status of Kyvo services.',
};

const services = [
  { name: 'Kyvo bot', description: 'Commands, events and moderation', icon: ShieldCheck },
  { name: 'Dashboard', description: 'Discord sign-in and server overview', icon: Server },
  { name: 'Command library', description: 'Searchable command registry', icon: Activity },
  { name: 'Discord API', description: 'Upstream platform dependency', icon: Radio },
];

export default function StatusPage() {
  return (
    <section className="relative pb-24 pt-32 sm:pt-36">
      <div className="container-page max-w-3xl">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-[11.5px] text-zinc-500 transition hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back home
        </Link>

        <div className="mt-8 flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-2 rounded-full border border-mint/25 bg-mint/10 px-3 py-1.5 text-[11px] font-semibold text-mint">
            <span className="dot" />
            All systems operational
          </span>
          <span className="text-[11px] text-zinc-600">Updated manually · no fake uptime graphs</span>
        </div>

        <h1 className="mt-5 text-4xl font-extrabold tracking-[-0.035em] text-white sm:text-5xl">
          System status
        </h1>
        <p className="mt-3 max-w-xl text-[14px] leading-7 text-zinc-400">
          The marketing site and command library are static and stay online with the host. The bot
          and dashboard depend on Discord, so occasional API hiccups can affect them.
        </p>

        <div className="mt-8 divide-y divide-white/[0.07] overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.015]">
          {services.map((service) => (
            <div key={service.name} className="flex items-center gap-4 px-5 py-4">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/[0.07] bg-white/[0.03] text-amber">
                <service.icon className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[13.5px] font-semibold text-white">{service.name}</p>
                <p className="text-[11.5px] text-zinc-500">{service.description}</p>
              </div>
              <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-mint">
                <Check className="h-3.5 w-3.5" />
                Operational
              </span>
            </div>
          ))}
        </div>

        <div className="mt-6 rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5 text-[12.5px] leading-6 text-zinc-500">
          Seeing a problem? Report it in the{' '}
          <a href={site.support} className="text-amber underline decoration-amber/30 underline-offset-4">
            support server
          </a>{' '}
          with the command, server and approximate time.
        </div>
      </div>
    </section>
  );
}
