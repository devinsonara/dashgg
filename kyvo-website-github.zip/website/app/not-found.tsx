import Link from 'next/link';
import { ArrowRight, Home, Search } from 'lucide-react';

export default function NotFound() {
  return (
    <section className="relative flex min-h-[70vh] items-center pb-20 pt-32">
      <div className="container-page text-center">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-amber">404</p>
        <h1 className="mx-auto mt-4 max-w-xl text-4xl font-extrabold tracking-[-0.04em] text-white sm:text-5xl">
          This page wandered off.
        </h1>
        <p className="mx-auto mt-4 max-w-md text-[14px] leading-7 text-zinc-400">
          Kyvo checked the logs — it&apos;s not here. Head back home or search the command library.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-2 sm:flex-row">
          <Link href="/" className="btn-primary w-full sm:w-auto">
            <Home className="h-4 w-4" />
            Back home
          </Link>
          <Link href="/commands" className="btn-ghost w-full sm:w-auto">
            <Search className="h-4 w-4" />
            Search commands
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
