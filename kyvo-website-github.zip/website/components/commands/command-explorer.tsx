'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Command,
  Copy,
  Crown,
  Hash,
  Search,
  Slash,
  Sparkles,
  X,
} from 'lucide-react';
import { categoryIcon } from '@/lib/icons';
import type { CommandCategory } from '@/lib/types';
import { cn } from '@/lib/utils';

type Mode = 'slash' | 'prefix';

export function CommandExplorer({
  categories,
  total,
  generatedAt,
}: {
  categories: CommandCategory[];
  total: number;
  generatedAt: string;
}) {
  const [query, setQuery] = useState('');
  const [active, setActive] = useState('all');
  const [mode, setMode] = useState<Mode>('slash');
  const [copied, setCopied] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const totalShown = useMemo(
    () => categories.reduce((sum, category) => sum + category.count, 0),
    [categories],
  );

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const initialQuery = params.get('q');
    const initialCategory = params.get('category');
    const initialMode = params.get('mode');
    if (initialQuery) setQuery(initialQuery);
    if (initialCategory && categories.some((category) => category.id === initialCategory)) {
      setActive(initialCategory);
    }
    if (initialMode === 'prefix') setMode('prefix');

    const hash = window.location.hash.replace('#', '');
    if (hash && categories.some((category) => category.id === hash)) {
      setActive(hash);
      window.requestAnimationFrame(() => {
        document.getElementById(`cat-${hash}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
  }, [categories]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (query.trim()) params.set('q', query.trim());
    else params.delete('q');
    if (active !== 'all') params.set('category', active);
    else params.delete('category');
    if (mode === 'prefix') params.set('mode', 'prefix');
    else params.delete('mode');
    const next = `${window.location.pathname}${params.toString() ? `?${params.toString()}` : ''}${window.location.hash}`;
    window.history.replaceState(null, '', next);
  }, [active, mode, query]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target?.tagName === 'INPUT' || target?.tagName === 'TEXTAREA' || target?.isContentEditable;
      if (typing) {
        if (event.key === 'Escape') {
          (target as HTMLElement).blur();
        }
        return;
      }
      if (event.key === '/' || ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k')) {
        event.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return categories
      .map((category) => {
        const groups = category.groups
          .map((group) => ({
            ...group,
            commands: group.commands.filter((command) => {
              if (!term) return true;
              return (
                command.toLowerCase().includes(term) ||
                group.name.toLowerCase().includes(term) ||
                category.name.toLowerCase().includes(term)
              );
            }),
          }))
          .filter((group) => group.commands.length > 0);
        return { ...category, groups };
      })
      .filter((category) => {
        if (active !== 'all' && category.id !== active) return false;
        return category.groups.length > 0;
      });
  }, [active, categories, query]);

  const resultCount = useMemo(
    () => filtered.reduce((sum, category) => sum + category.groups.reduce((n, group) => n + group.commands.length, 0), 0),
    [filtered],
  );

  const copy = async (command: string) => {
    const label = mode === 'slash' ? `/${command}` : `,${command}`;
    try {
      await navigator.clipboard.writeText(label);
      setCopied(label);
      window.setTimeout(() => setCopied((value) => (value === label ? null : value)), 1700);
    } catch {
      setCopied(null);
    }
  };

  const activeCategory = categories.find((category) => category.id === active);

  return (
    <section className="relative pb-24">
      <div className="container-page">
        <div className="rounded-3xl border border-white/[0.08] bg-gradient-to-b from-white/[0.035] to-transparent shadow-card">
          <div className="flex flex-col gap-3 border-b border-white/[0.07] p-4 lg:flex-row lg:items-center lg:justify-between lg:p-5">
            <div className="flex h-11 flex-1 items-center gap-2.5 rounded-2xl border border-white/[0.08] bg-black/30 px-3.5 transition focus-within:border-amber/40 focus-within:bg-black/45 lg:max-w-2xl">
              <Search className="h-4 w-4 shrink-0 text-zinc-500" />
              <input
                ref={inputRef}
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder={`Search ${totalShown} commands…`}
                aria-label="Search commands"
                className="h-full w-full bg-transparent text-[13px] text-white placeholder:text-zinc-600 focus:outline-none"
              />
              {query ? (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  aria-label="Clear search"
                  className="text-zinc-500 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              ) : (
                <kbd className="hidden rounded border border-white/10 bg-white/[0.04] px-1.5 py-0.5 font-mono text-[9px] text-zinc-500 sm:block">
                  /
                </kbd>
              )}
            </div>

            <div className="flex items-center justify-between gap-3">
              <div className="inline-flex items-center rounded-xl border border-white/[0.08] bg-black/25 p-1">
                <button
                  type="button"
                  onClick={() => setMode('slash')}
                  className={cn(
                    'inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11.5px] font-medium transition',
                    mode === 'slash' ? 'bg-amber/15 text-amber-soft' : 'text-zinc-500 hover:text-zinc-200',
                  )}
                >
                  <Slash className="h-3 w-3" />
                  Slash
                </button>
                <button
                  type="button"
                  onClick={() => setMode('prefix')}
                  className={cn(
                    'inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11.5px] font-medium transition',
                    mode === 'prefix' ? 'bg-amber/15 text-amber-soft' : 'text-zinc-500 hover:text-zinc-200',
                  )}
                >
                  <Hash className="h-3 w-3" />
                  Prefix
                </button>
              </div>
              <span className="font-mono text-[10px] text-zinc-600">{resultCount} shown</span>
            </div>
          </div>

          <div className="grid lg:grid-cols-[250px_1fr]">
            <aside className="border-b border-white/[0.07] p-3 lg:border-b-0 lg:border-r">
              <div className="flex gap-1.5 overflow-x-auto pb-1 scroll-thin lg:hidden">
                <CategoryPill
                  label="All"
                  active={active === 'all'}
                  onClick={() => setActive('all')}
                />
                {categories.map((category) => (
                  <CategoryPill
                    key={category.id}
                    label={category.name}
                    active={active === category.id}
                    onClick={() => setActive(category.id)}
                  />
                ))}
              </div>

              <div className="hidden lg:block">
                <button
                  type="button"
                  onClick={() => setActive('all')}
                  className={cn(
                    'flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-[12.5px] transition',
                    active === 'all'
                      ? 'bg-amber/10 text-amber-soft'
                      : 'text-zinc-500 hover:bg-white/[0.04] hover:text-zinc-200',
                  )}
                >
                  <Command className="h-4 w-4" />
                  All commands
                  <span className="ml-auto font-mono text-[9px] text-zinc-600">{totalShown}</span>
                </button>

                <div className="mt-1 max-h-[calc(100vh-16rem)] space-y-0.5 overflow-y-auto scroll-thin pr-1">
                  {categories.map((category) => {
                    const Icon = categoryIcon(category.icon);
                    return (
                      <button
                        key={category.id}
                        type="button"
                        onClick={() => setActive(category.id)}
                        className={cn(
                          'flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-[12.5px] transition',
                          active === category.id
                            ? 'bg-amber/10 text-amber-soft'
                            : 'text-zinc-500 hover:bg-white/[0.04] hover:text-zinc-200',
                        )}
                      >
                        <Icon className="h-4 w-4 shrink-0" />
                        <span className="truncate">{category.name}</span>
                        {category.premium && <Crown className="h-3 w-3 shrink-0 text-amber/70" />}
                        <span className="ml-auto font-mono text-[9px] text-zinc-600">{category.count}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="mt-4 rounded-2xl border border-white/[0.07] bg-black/20 p-3">
                  <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-zinc-500">
                    <Sparkles className="h-3 w-3 text-amber" />
                    Tip
                  </p>
                  <p className="mt-1.5 text-[11px] leading-5 text-zinc-600">
                    Press <kbd className="rounded border border-white/10 px-1 font-mono text-[9px]">/</kbd>{' '}
                    to search, click a command to copy it.
                  </p>
                </div>
              </div>
            </aside>

            <div className="min-w-0 p-4 sm:p-6">
              {filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 px-6 py-20 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.03]">
                    <Search className="h-5 w-5 text-zinc-500" />
                  </div>
                  <p className="mt-4 text-sm font-medium text-zinc-300">No commands found</p>
                  <p className="mt-1 max-w-sm text-[12px] leading-5 text-zinc-600">
                    Nothing matches “{query}”. Try a broader term like “mod”, “music”, “ticket” or
                    “automod”.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setQuery('');
                      setActive('all');
                    }}
                    className="btn-ghost mt-5 !px-4 !py-2 text-[12px]"
                  >
                    Reset filters
                  </button>
                </div>
              ) : (
                <div className="space-y-10">
                  {filtered.map((category) => {
                    const Icon = categoryIcon(category.icon);
                    return (
                      <div key={category.id} id={`cat-${category.id}`} className="scroll-mt-28">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="flex items-start gap-3">
                            <span className="icon-tile h-10 w-10 rounded-xl">
                              <Icon className="h-4 w-4" />
                            </span>
                            <div>
                              <h2 className="flex items-center gap-2 text-[17px] font-semibold text-white">
                                {category.name}
                                {category.premium && (
                                  <span className="inline-flex items-center gap-1 rounded-full border border-amber/25 bg-amber/10 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-amber">
                                    <Crown className="h-2.5 w-2.5" />
                                    Premium
                                  </span>
                                )}
                              </h2>
                              <p className="mt-1 max-w-2xl text-[12px] leading-5 text-zinc-500">
                                {category.description}
                              </p>
                            </div>
                          </div>
                          <span className="rounded-full border border-white/[0.08] bg-white/[0.025] px-2.5 py-1 font-mono text-[10px] text-zinc-500">
                            {category.count} commands
                          </span>
                        </div>

                        <div className="mt-5 space-y-5">
                          {category.groups.map((group) => (
                            <div key={group.name}>
                              <div className="mb-2.5 flex items-center gap-3">
                                <h3 className="text-[10px] font-semibold uppercase tracking-[0.16em] text-zinc-500">
                                  {group.name}
                                </h3>
                                <div className="h-px flex-1 bg-white/[0.05]" />
                                <span className="font-mono text-[9px] text-zinc-700">
                                  {group.commands.length}
                                </span>
                              </div>
                              <div className="grid gap-1.5 sm:grid-cols-2 xl:grid-cols-3">
                                {group.commands.map((command) => {
                                  const label = `${mode === 'slash' ? '/' : ','}${command}`;
                                  const isCopied = copied === label;
                                  return (
                                    <button
                                      key={`${category.id}-${group.name}-${command}`}
                                      type="button"
                                      onClick={() => copy(command)}
                                      title={`Copy ${label}`}
                                      className="group flex min-w-0 items-center gap-2 rounded-xl border border-white/[0.06] bg-black/25 px-2.5 py-2 text-left transition hover:border-amber/30 hover:bg-amber/[0.06]"
                                    >
                                      <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-zinc-300 group-hover:text-amber-soft">
                                        {label}
                                      </code>
                                      {isCopied ? (
                                        <Check className="h-3.5 w-3.5 shrink-0 text-mint" />
                                      ) : (
                                        <Copy className="h-3.5 w-3.5 shrink-0 text-zinc-700 transition group-hover:text-amber" />
                                      )}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="mt-10 flex flex-col gap-2 border-t border-white/[0.06] pt-4 text-[10.5px] text-zinc-600 sm:flex-row sm:items-center sm:justify-between">
                <p>
                  Generated from Kyvo&apos;s help registry ·{' '}
                  {new Date(generatedAt).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                    timeZone: 'UTC',
                  })}
                </p>
                <p className="flex items-center gap-1.5">
                  <span className="inline-block h-1.5 w-1.5 rounded-full bg-mint" />
                  {total} total commands
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        aria-live="polite"
        className={cn(
          'fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-full border border-mint/25 bg-ink-850/95 px-4 py-2 text-[12px] text-mint shadow-xl backdrop-blur-xl transition-all duration-300',
          copied ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-3 opacity-0',
        )}
      >
        <span className="inline-flex items-center gap-2">
          <Check className="h-3.5 w-3.5" />
          Copied <code className="font-mono text-white">{copied}</code>
        </span>
      </div>
    </section>
  );
}

function CategoryPill({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'shrink-0 rounded-full border px-3 py-1.5 text-[11px] transition',
        active
          ? 'border-amber/30 bg-amber/10 text-amber-soft'
          : 'border-white/[0.08] text-zinc-500',
      )}
    >
      {label}
    </button>
  );
}
