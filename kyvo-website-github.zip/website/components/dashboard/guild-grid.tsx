'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { ArrowRight, Plus, Search, ShieldCheck, Check } from 'lucide-react';
import { guildIconUrl } from '@/lib/avatar';
import type { DiscordGuild } from '@/lib/types';
import { cn, initials } from '@/lib/utils';
import { site } from '@/lib/site';

export function GuildGrid({
  guilds,
  botGuildIds,
}: {
  guilds: DiscordGuild[];
  botGuildIds: string[] | null;
}) {
  const [query, setQuery] = useState('');
  const botSet = useMemo(() => (botGuildIds ? new Set(botGuildIds) : null), [botGuildIds]);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    const sorted = [...guilds].sort((a, b) => {
      const aBot = botSet ? Number(botSet.has(a.id)) : 0;
      const bBot = botSet ? Number(botSet.has(b.id)) : 0;
      return bBot - aBot || Number(b.owner) - Number(a.owner) || a.name.localeCompare(b.name);
    });
    if (!term) return sorted;
    return sorted.filter((guild) => guild.name.toLowerCase().includes(term));
  }, [botSet, guilds, query]);

  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-[-0.02em] text-white sm:text-3xl">
            Your servers
          </h1>
          <p className="mt-1 text-[13px] text-zinc-500">
            {guilds.length} server{guilds.length === 1 ? '' : 's'} where you can manage Kyvo.
          </p>
        </div>
        <div className="flex h-10 w-full items-center gap-2 rounded-xl border border-white/[0.08] bg-black/30 px-3 transition focus-within:border-amber/40 sm:w-64">
          <Search className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Find a server…"
            aria-label="Find a server"
            className="w-full bg-transparent text-[12.5px] text-white placeholder:text-zinc-600 focus:outline-none"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-white/10 px-6 py-14 text-center">
          <p className="text-sm font-medium text-zinc-300">No server matches “{query}”.</p>
          <p className="mt-1 text-[12px] text-zinc-600">Try another name, or invite Kyvo to a new server.</p>
          <a href={site.invite} target="_blank" rel="noreferrer" className="btn-primary mt-5 !px-4 !py-2 text-[12px]">
            <Plus className="h-3.5 w-3.5" />
            Add Kyvo
          </a>
        </div>
      ) : (
        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((guild) => {
            const icon = guildIconUrl(guild.id, guild.icon, 128);
            const installed = botSet ? botSet.has(guild.id) : null;
            return (
              <div
                key={guild.id}
                className="group rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4 transition hover:border-amber/25 hover:bg-white/[0.035]"
              >
                <div className="flex items-start gap-3">
                  {icon ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={icon}
                      alt=""
                      width={48}
                      height={48}
                      className="h-12 w-12 shrink-0 rounded-2xl border border-white/10 object-cover"
                    />
                  ) : (
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-amber/25 to-amber/5 text-sm font-bold text-amber">
                      {initials(guild.name)}
                    </span>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[14px] font-semibold text-white">{guild.name}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      {guild.owner && (
                        <span className="rounded-md border border-amber/20 bg-amber/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-amber">
                          Owner
                        </span>
                      )}
                      {installed === true && (
                        <span className="inline-flex items-center gap-1 rounded-md border border-mint/20 bg-mint/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-mint">
                          <ShieldCheck className="h-2.5 w-2.5" />
                          Kyvo is here
                        </span>
                      )}
                      {installed === false && (
                        <span className="rounded-md border border-white/10 bg-white/[0.03] px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-zinc-500">
                          Not installed
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <Link
                    href={`/dashboard/${guild.id}`}
                    className={cn(
                      'inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-[11.5px] font-medium transition',
                      'border-white/[0.08] bg-white/[0.03] text-zinc-300 hover:border-amber/30 hover:text-amber-soft',
                    )}
                  >
                    Manage
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                  {installed === false && (
                    <a
                      href={site.invite}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center justify-center gap-1 rounded-xl border border-amber/25 bg-amber/10 px-3 py-2 text-[11.5px] font-medium text-amber transition hover:bg-amber/15"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      Add
                    </a>
                  )}
                  {installed === true && (
                    <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-mint/15 bg-mint/[0.06] text-mint">
                      <Check className="h-4 w-4" />
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
