'use client';

import { useEffect, useState } from 'react';
import {
  ArrowUpRight,
  Bot,
  CalendarDays,
  Check,
  Copy,
  Gift,
  Hash,
  Loader2,
  LockKeyhole,
  Music2,
  ScrollText,
  ShieldCheck,
  Sparkles,
  Terminal,
  TrendingUp,
  UserCheck,
  Users,
  Zap,
} from 'lucide-react';
import { CopyIdButton } from '@/components/dashboard/copy-id-button';
import { cn } from '@/lib/utils';
import { site } from '@/lib/site';
import { fetchModuleConfig, updateModuleConfig, fetchPremiumStatus, fetchGuildOverview } from '@/lib/bot-api';

const modules = [
  {
    key: 'antinuke',
    icon: ShieldCheck,
    name: 'Antinuke',
    description: 'Real-time protection against mass bans, kicks, webhook spam and permission abuse.',
    premium: false,
  },
  {
    key: 'automod',
    icon: Bot,
    name: 'Automod',
    description: 'Spam, invites, caps, mass mentions and banned words handled automatically.',
    premium: false,
  },
  {
    key: 'welcome',
    icon: UserCheck,
    name: 'Welcome & verify',
    description: 'Greet new members, send farewells and gate access with verification.',
    premium: false,
  },
  {
    key: 'leveling',
    icon: TrendingUp,
    name: 'Leveling',
    description: 'XP, rank cards and leaderboards with role rewards.',
    premium: false,
  },
  {
    key: 'tickets',
    icon: ScrollText,
    name: 'Tickets',
    description: 'Support panels, categories, claims and transcripts.',
    premium: false,
  },
  {
    key: 'music',
    icon: Music2,
    name: 'Music',
    description: 'Queue, filters, 24/7 mode and now-playing cards.',
    premium: true,
  },
  {
    key: 'logging',
    icon: ScrollText,
    name: 'Logging',
    description: 'Audit every ban, kick, edit, role change and join.',
    premium: false,
  },
  {
    key: 'giveaways',
    icon: Gift,
    name: 'Giveaways',
    description: 'Scheduled giveaways, requirements and rerolls.',
    premium: false,
  },
];

const protections = [
  'Anti-ban & anti-kick',
  'Anti-webhook creation',
  'Anti-bot add',
  'Anti-channel delete',
  'Anti-role delete',
  'Anti-raid',
  'Emergency lockdown',
  'Whitelist & trusted users',
];

export function ModuleManager({
  guildId,
  installed,
  premium,
  initialConfigs,
}: {
  guildId: string;
  installed: boolean;
  premium: boolean;
  initialConfigs: Record<string, any>;
}) {
  const [configs, setConfigs] = useState<Record<string, any>>(initialConfigs);
  const [saving, setSaving] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: 'success' | 'error' }>>([]);

  const showToast = (message: string, type: 'success' | 'error') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  };

  const handleToggle = async (module: string, key: string, value: boolean) => {
    setSaving(module);
    try {
      const current = configs[module] || {};
      const updated = { ...current, [key]: value };
      await updateModuleConfig(guildId, module, updated);
      setConfigs((c) => ({ ...c, [module]: updated }));
      showToast(`${module} ${value ? 'enabled' : 'disabled'}`, 'success');
    } catch (e) {
      showToast(`Failed: ${(e as Error).message}`, 'error');
    } finally {
      setSaving(null);
    }
  };

  const handleSave = async (module: string, data: any) => {
    setSaving(module);
    try {
      await updateModuleConfig(guildId, module, data);
      setConfigs((c) => ({ ...c, [module]: data }));
      showToast(`${module} saved`, 'success');
    } catch (e) {
      showToast(`Failed: ${(e as Error).message}`, 'error');
    } finally {
      setSaving(null);
    }
  };

  if (!installed) {
    return (
      <div className="mt-6 rounded-2xl border border-amber/20 bg-amber/[0.05] p-5 text-center">
        <p className="text-[13px] text-zinc-400">
          Kyvo is not installed in this server. Add it first, then refresh to manage modules.
        </p>
        <a href={site.invite} target="_blank" rel="noreferrer" className="btn-primary mt-4 inline-block">
          Add Kyvo
        </a>
      </div>
    );
  }

  return (
    <div>
      <div className="mt-6 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-[17px] font-semibold text-white">Modules</h2>
          <p className="mt-1 text-[12px] text-zinc-500">
            Toggle modules and configure settings. Changes are saved instantly via the bot API.
          </p>
        </div>
        <span className="rounded-full border border-white/[0.08] bg-white/[0.025] px-2.5 py-1 text-[10px] text-zinc-500">
          {modules.filter((m) => !m.premium || premium).length} available
        </span>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {modules
          .filter((m) => !m.premium || premium)
          .map((module) => {
            const cfg = configs[module.key] || {};
            const enabled = !!cfg.enabled;
            const isSaving = saving === module.key;

            return (
              <ModuleCard
                key={module.key}
                module={module}
                enabled={enabled}
                config={cfg}
                isSaving={isSaving}
                onToggle={(value) => handleToggle(module.key, 'enabled', value)}
                onSave={(data) => handleSave(module.key, data)}
                premium={module.premium && !premium}
              />
            );
          })}
      </div>

      <div className="mt-6 flex items-start gap-3 rounded-2xl border border-amber/20 bg-amber/[0.05] p-4">
        <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
        <div>
          <h3 className="text-[12.5px] font-semibold text-amber-soft">Live toggles active</h3>
          <p className="mt-1 text-[11.5px] leading-5 text-zinc-500">
            Changes here update the bot&apos;s SQLite databases directly. No restart needed.
          </p>
        </div>
      </div>

      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={cn(
            'fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-xl border px-4 py-3 text-[12px] shadow-xl backdrop-blur-xl animate-fade-up',
            toast.type === 'success'
              ? 'border-mint/25 bg-mint/10 text-mint'
              : 'border-danger/25 bg-danger/10 text-danger/90',
          )}
        >
          {toast.type === 'success' ? <Check className="h-3.5 w-3.5" /> : <Terminal className="h-3.5 w-3.5" />}
          {toast.message}
        </div>
      ))}
    </div>
  );
}

function ModuleCard({
  module,
  enabled,
  config,
  isSaving,
  onToggle,
  onSave,
  premium,
}: {
  module: (typeof modules)[0];
  enabled: boolean;
  config: Record<string, any>;
  isSaving: boolean;
  onToggle: (value: boolean) => void;
  onSave: (data: any) => void;
  premium: boolean;
}) {
  const [expanded, setExpanded] = useState(false);

  if (premium) {
    return (
      <div className="card relative overflow-hidden p-5 opacity-60">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-amber/10 to-transparent" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="icon-tile h-10 w-10 rounded-xl">
              <module.icon className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-[13.5px] font-semibold text-white">{module.name}</h3>
              <p className="text-[11px] text-zinc-500">Premium feature</p>
            </div>
          </div>
          <span className="rounded-full border border-amber/25 bg-amber/10 px-2 py-0.5 text-[9px] font-semibold text-amber">
            Premium
          </span>
        </div>
        <p className="mt-3 text-[11.5px] leading-5 text-zinc-500">{module.description}</p>
      </div>
    );
  }

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="icon-tile h-10 w-10 rounded-xl">
            <module.icon className="h-4 w-4" />
          </span>
          <div>
            <h3 className="text-[13.5px] font-semibold text-white">{module.name}</h3>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Switch
            checked={enabled}
            onCheckedChange={onToggle}
            disabled={isSaving}
            className="data-[state=checked]:bg-amber data-[state=checked]:border-amber/30"
          />
          {isSaving && <Loader2 className="h-4 w-4 animate-spin text-amber" />}
        </div>
      </div>

      <p className="mt-2 text-[11.5px] leading-5 text-zinc-500">{module.description}</p>

      {enabled && (
        <div className="mt-4">
          <button
            type="button"
            onClick={() => setExpanded(!expanded)}
            className="inline-flex items-center gap-1.5 text-[11px] font-medium text-zinc-400 transition hover:text-amber"
          >
            {expanded ? 'Hide settings' : 'Configure'}
            <span className="transition transform duration-200" style={{ transform: expanded ? 'rotate(180deg)' : 'rotate(0)' }}>
              ▾
            </span>
          </button>

          {expanded && (
            <div className="mt-3 space-y-3" style={{ animation: 'fade-up 0.2s ease-out' }}>
              {module.key === 'antinuke' && <AntinukeConfig config={config} onSave={onSave} />}
              {module.key === 'automod' && <AutomodConfig config={config} onSave={onSave} />}
              {module.key === 'welcome' && <WelcomeConfig config={config} onSave={onSave} />}
              {module.key === 'autorole' && <AutoroleConfig config={config} onSave={onSave} />}
              {module.key === 'leveling' && <LevelingConfig config={config} onSave={onSave} />}
              {module.key === 'tickets' && <TicketsConfig config={config} onSave={onSave} />}
              {module.key === 'logging' && <LoggingConfig config={config} onSave={onSave} />}
              {module.key === 'giveaways' && <GiveawaysConfig config={config} onSave={onSave} />}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Input({ label, value, onChange, type = 'text', placeholder }: { label: string; value: any; onChange: (v: any) => void; type?: string; placeholder?: string }) {
  return (
    <div>
      <label className="block text-[10px] font-medium uppercase tracking-[0.1em] text-zinc-500 mb-1">{label}</label>
      <input
        type={type}
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-white/[0.08] bg-black/30 px-3 py-2 text-[12px] text-white placeholder:text-zinc-600 focus:border-amber/40 focus:bg-black/45 outline-none"
      />
    </div>
  );
}

function NumberInput({ label, value, onChange, min, max }: { label: string; value: number; onChange: (v: number) => void; min?: number; max?: number }) {
  return (
    <div>
      <label className="block text-[10px] font-medium uppercase tracking-[0.1em] text-zinc-500 mb-1">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        min={min}
        max={max}
        className="w-full rounded-xl border border-white/[0.08] bg-black/30 px-3 py-2 text-[12px] text-white focus:border-amber/40 focus:bg-black/45 outline-none"
      />
    </div>
  );
}

function ChannelInput({ label, value, onChange }: { label: string; value: number | null; onChange: (v: number | null) => void }) {
  return (
    <div>
      <label className="block text-[10px] font-medium uppercase tracking-[0.1em] text-zinc-500 mb-1">{label}</label>
      <input
        type="text"
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value ? Number(e.target.value) : null)}
        placeholder="Channel ID (or blank to clear)"
        className="w-full rounded-xl border border-white/[0.08] bg-black/30 px-3 py-2 text-[12px] text-white placeholder:text-zinc-600 focus:border-amber/40 focus:bg-black/45 outline-none font-mono"
      />
    </div>
  );
}

function Switch({ checked, onCheckedChange, disabled, className }: { checked: boolean; onCheckedChange: (v: boolean) => void; disabled?: boolean; className?: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => !disabled && onCheckedChange(!checked)}
      className={cn(
        'relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber focus-visible:ring-offset-2 focus-visible:ring-offset-ink-950',
        'disabled:cursor-not-allowed disabled:opacity-50',
        checked
          ? 'bg-amber border-amber'
          : 'bg-white/[0.07] border-white/[0.12]',
        className,
      )}
    >
      <span
        className={cn(
          'pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
          'shadow-[0_2px_4px_rgba(0,0,0,0.3)]',
          checked ? 'translate-x-5' : 'translate-x-0',
        )}
      />
    </button>
  );
}

function AntinukeConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <h4 className="text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-500">Whitelist</h4>
      <p className="text-[11px] text-zinc-600">Manage whitelisted users in Discord with <code className="font-mono text-amber/80">/whitelist</code>. Dashboard editing coming soon.</p>
    </div>
  );
}

function AutomodConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  const [loggingChannel, setLoggingChannel] = useState(config.logging_channel || '');

  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <ChannelInput
        label="Log channel ID"
        value={config.logging_channel}
        onChange={setLoggingChannel}
      />
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => onSave({ ...config, logging_channel: loggingChannel ? Number(loggingChannel) : null })}
          className="btn-primary !px-3 !py-1.5 text-[11px]"
        >
          Save
        </button>
        <button
          type="button"
          onClick={() => onSave({ ...config, logging_channel: null })}
          className="btn-ghost !px-3 !py-1.5 text-[11px]"
        >
          Clear
        </button>
      </div>
      <p className="text-[11px] text-zinc-600">Punishments and ignored channels/roles are managed in Discord with <code className="font-mono text-amber/80">/automod</code>.</p>
    </div>
  );
}

function WelcomeConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  const [channelId, setChannelId] = useState(config.channel_id || '');
  const [message, setMessage] = useState(config.message || '');
  const [autoDelete, setAutoDelete] = useState(config.auto_delete || '');
  const [leaveChannelId, setLeaveChannelId] = useState(config.leave_channel_id || '');
  const [leaveMessage, setLeaveMessage] = useState(config.leave_message || '');
  const [leaveAutoDelete, setLeaveAutoDelete] = useState(config.leave_auto_delete || '');

  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <ChannelInput label="Welcome channel" value={config.channel_id} onChange={setChannelId} />
        <NumberInput label="Auto-delete (seconds)" value={config.auto_delete || 0} onChange={setAutoDelete} min={0} max={600} />
      </div>
      <Input label="Welcome message" value={message} onChange={setMessage} placeholder="Welcome {user} to {server}!" />
      <div className="pt-2 border-t border-white/[0.06]">
        <h4 className="text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-500 mb-2">Farewell</h4>
        <div className="grid gap-3 sm:grid-cols-2">
          <ChannelInput label="Leave channel" value={config.leave_channel_id} onChange={setLeaveChannelId} />
          <NumberInput label="Auto-delete (seconds)" value={config.leave_auto_delete || 0} onChange={setLeaveAutoDelete} min={0} max={600} />
        </div>
        <Input label="Leave message" value={leaveMessage} onChange={setLeaveMessage} placeholder="Goodbye {user}..." />
      </div>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() =>
            onSave({
              ...config,
              channel_id: channelId ? Number(channelId) : null,
              message,
              auto_delete: autoDelete ? Number(autoDelete) : null,
              leave_channel_id: leaveChannelId ? Number(leaveChannelId) : null,
              leave_message: leaveMessage,
              leave_auto_delete: leaveAutoDelete ? Number(leaveAutoDelete) : null,
            })
          }
          className="btn-primary !px-3 !py-1.5 text-[11px]"
        >
          Save all
        </button>
      </div>
    </div>
  );
}

function AutoroleConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  const [humans, setHumans] = useState(config.humans || '');
  const [bots, setBots] = useState(config.bots || '');

  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <ChannelInput label="Human role ID" value={config.humans} onChange={setHumans} />
        <ChannelInput label="Bot role ID" value={config.bots} onChange={setBots} />
      </div>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => onSave({ humans: humans ? Number(humans) : null, bots: bots ? Number(bots) : null })}
          className="btn-primary !px-3 !py-1.5 text-[11px]"
        >
          Save
        </button>
        <button
          type="button"
          onClick={() => onSave({ humans: null, bots: null })}
          className="btn-ghost !px-3 !py-1.5 text-[11px]"
        >
          Clear
        </button>
      </div>
    </div>
  );
}

function LevelingConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  const [announce, setAnnounce] = useState(config.announce_channel || '');
  const [style, setStyle] = useState(config.style || '');
  const [minXp, setMinXp] = useState(config.min_xp || 15);
  const [maxXp, setMaxXp] = useState(config.max_xp || 25);
  const [cooldown, setCooldown] = useState(config.cooldown || 60);
  const [mode, setMode] = useState(config.mode || 'level');
  const [voiceXp, setVoiceXp] = useState(config.voice_xp || 0);

  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <ChannelInput label="Announce channel" value={config.announce_channel} onChange={setAnnounce} />
        <Input label="Style" value={style} onChange={setStyle} placeholder="default / minimal / fancy" />
      </div>
      <div className="grid gap-3 sm:grid-cols-4">
        <NumberInput label="Min XP" value={minXp} onChange={setMinXp} min={1} max={100} />
        <NumberInput label="Max XP" value={maxXp} onChange={setMaxXp} min={1} max={100} />
        <NumberInput label="Cooldown (s)" value={cooldown} onChange={setCooldown} min={0} max={3600} />
        <NumberInput label="Voice XP/min" value={voiceXp} onChange={setVoiceXp} min={0} max={50} />
      </div>
      <div>
        <label className="block text-[10px] font-medium uppercase tracking-[0.1em] text-zinc-500 mb-1">Mode</label>
        <select
          value={mode}
          onChange={(e) => setMode(e.target.value)}
          className="w-full rounded-xl border border-white/[0.08] bg-black/30 px-3 py-2 text-[12px] text-white focus:border-amber/40 focus:bg-black/45 outline-none"
        >
          <option value="level">Level</option>
          <option value="xp">XP</option>
        </select>
      </div>
      <button
        type="button"
        onClick={() =>
          onSave({
            announce_channel: announce ? Number(announce) : null,
            style: style || null,
            min_xp: minXp,
            max_xp: maxXp,
            cooldown,
            mode,
            voice_xp: voiceXp,
          })
        }
        className="btn-primary !px-3 !py-1.5 text-[11px]"
      >
        Save
      </button>
    </div>
  );
}

function TicketsConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  const [logChannel, setLogChannel] = useState(config.log_channel_id || '');
  const [panelChannel, setPanelChannel] = useState(config.panel_channel_id || '');
  const [categoryOpen, setCategoryOpen] = useState(config.open_cat_id || '');
  const [categoryClosed, setCategoryClosed] = useState(config.closed_cat_id || '');
  const [panelTitle, setPanelTitle] = useState(config.panel_title || '');
  const [panelDesc, setPanelDesc] = useState(config.panel_description || '');
  const [buttonLabel, setButtonLabel] = useState(config.button_label || '');
  const [embedColor, setEmbedColor] = useState(config.embed_color || '');

  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <ChannelInput label="Log channel" value={config.log_channel_id} onChange={setLogChannel} />
        <ChannelInput label="Panel channel" value={config.panel_channel_id} onChange={setPanelChannel} />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <ChannelInput label="Open category" value={config.open_cat_id} onChange={setCategoryOpen} />
        <ChannelInput label="Closed category" value={config.closed_cat_id} onChange={setCategoryClosed} />
      </div>
      <Input label="Panel title" value={panelTitle} onChange={setPanelTitle} placeholder="Support Tickets" />
      <Input label="Panel description" value={panelDesc} onChange={setPanelDesc} placeholder="Click the button below to create a ticket." />
      <Input label="Button label" value={buttonLabel} onChange={setButtonLabel} placeholder="Create Ticket" />
      <Input label="Embed color (hex)" value={embedColor} onChange={setEmbedColor} placeholder="#FFB43C" />
      <button
        type="button"
        onClick={() =>
          onSave({
            log_channel_id: logChannel ? Number(logChannel) : null,
            panel_channel_id: panelChannel ? Number(panelChannel) : null,
            open_cat_id: categoryOpen ? Number(categoryOpen) : null,
            closed_cat_id: categoryClosed ? Number(categoryClosed) : null,
            panel_title: panelTitle || null,
            panel_description: panelDesc || null,
            button_label: buttonLabel || null,
            embed_color: embedColor || null,
          })
        }
        className="btn-primary !px-3 !py-1.5 text-[11px]"
      >
        Save
      </button>
    </div>
  );
}

function LoggingConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  const [channels, setChannels] = useState<Record<string, string>>(
    Object.fromEntries(Object.entries(config.channels || {}).map(([k, v]) => [k, String(v)]))
  );

  const logTypes = [
    'ban', 'kick', 'mute', 'unmute', 'warn', 'role_create', 'role_delete', 'role_update',
    'channel_create', 'channel_delete', 'channel_update', 'message_delete', 'message_edit',
    'member_join', 'member_leave', 'voice_join', 'voice_leave', 'voice_move',
    'invite_create', 'invite_delete', 'webhook_create', 'webhook_delete', 'bot_add', 'bot_remove',
  ];

  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <div className="grid gap-2 max-h-60 overflow-y-auto">
        {logTypes.map((type) => (
          <div key={type} className="flex items-center gap-3">
            <label className="w-36 text-[11px] font-medium text-zinc-400 capitalize">{type.replace('_', ' ')}</label>
            <input
              type="text"
              value={channels[type] || ''}
              onChange={(e) => setChannels((c) => ({ ...c, [type]: e.target.value }))}
              placeholder="Channel ID"
              className="flex-1 rounded-xl border border-white/[0.08] bg-black/30 px-3 py-1.5 text-[11px] text-white placeholder:text-zinc-600 focus:border-amber/40 focus:bg-black/45 outline-none font-mono"
            />
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={() =>
          onSave({
            channels: Object.fromEntries(
              Object.entries(channels).map(([k, v]) => [k, v ? Number(v) : null]).filter(([, v]) => v)
            ),
          })
        }
        className="btn-primary !px-3 !py-1.5 text-[11px]"
      >
        Save all
      </button>
    </div>
  );
}

function GiveawaysConfig({ config, onSave }: { config: any; onSave: (data: any) => void }) {
  const [bonusRoles, setBonusRoles] = useState<string>((config.bonus_roles || []).join(', '));

  return (
    <div className="space-y-3 border-t border-white/[0.06] pt-3">
      <Input
        label="Bonus role IDs (comma-separated)"
        value={bonusRoles}
        onChange={setBonusRoles}
        placeholder="123456789, 987654321"
      />
      <button
        type="button"
        onClick={() =>
          onSave({
            bonus_roles: bonusRoles.split(',').map((s) => s.trim()).filter(Boolean).map(Number),
          })
        }
        className="btn-primary !px-3 !py-1.5 text-[11px]"
      >
        Save
      </button>
    </div>
  );
}