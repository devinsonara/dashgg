'use client';

import { useState } from 'react';
import { Check, Copy } from 'lucide-react';

export function CopyIdButton({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <button
      type="button"
      onClick={copy}
      className="inline-flex items-center gap-1.5 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-[11.5px] font-medium text-zinc-400 transition hover:border-amber/30 hover:text-amber-soft"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-mint" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied' : 'Copy server ID'}
    </button>
  );
}
