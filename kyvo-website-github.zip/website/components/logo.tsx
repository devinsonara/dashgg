import { cn } from '@/lib/utils';

export function Logo({ className, withWordmark = true }: { className?: string; withWordmark?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <svg
        viewBox="0 0 48 48"
        role="img"
        aria-label="Kyvo logo"
        className="h-9 w-9 drop-shadow-[0_0_18px_rgba(255,180,60,0.35)]"
      >
        <defs>
          <linearGradient id="kyvo-mark" x1="8" y1="4" x2="42" y2="46" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFD08A" />
            <stop offset="0.48" stopColor="#FFB43C" />
            <stop offset="1" stopColor="#E8951B" />
          </linearGradient>
        </defs>
        <rect x="1.5" y="1.5" width="45" height="45" rx="14" fill="url(#kyvo-mark)" />
        <rect x="1.5" y="1.5" width="45" height="45" rx="14" fill="none" stroke="rgba(255,255,255,.35)" strokeWidth="1" />
        <path
          d="M16.5 12.5v23M31.5 12.5 18.8 25.4l12.9 10.1"
          fill="none"
          stroke="#0A0A0D"
          strokeWidth="3.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="35.5" cy="13.5" r="2.2" fill="#0A0A0D" opacity=".9" />
      </svg>
      {withWordmark && (
        <span className="text-[19px] font-extrabold tracking-[-0.03em] text-white">
          Kyvo<span className="text-amber">.</span>
        </span>
      )}
    </span>
  );
}
