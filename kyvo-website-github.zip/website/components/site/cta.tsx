import { ArrowRight, ShieldCheck } from 'lucide-react';
import { Reveal } from './reveal';
import { site } from '@/lib/site';
import { DiscordIcon } from '@/components/discord-icon';

export function CTA() {
  return (
    <section className="relative py-16">
      <div className="container-page">
        <Reveal>
          <div className="noise relative overflow-hidden rounded-[32px] border border-amber/20 bg-gradient-to-br from-[#1a1206] via-[#12100b] to-ink-950 px-6 py-14 text-center shadow-glow sm:px-12 sm:py-16">
            <div aria-hidden className="absolute inset-0 grid-bg opacity-30" />
            <div aria-hidden className="absolute left-1/2 top-0 h-64 w-[34rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber/[0.18] blur-[90px]" />
            <div aria-hidden className="absolute -bottom-24 left-1/2 h-52 w-[28rem] -translate-x-1/2 rounded-full bg-amber/[0.08] blur-[70px]" />

            <div className="relative mx-auto max-w-2xl">
              <span className="inline-flex items-center gap-2 rounded-full border border-amber/25 bg-amber/10 px-3 py-1 text-[10.5px] font-semibold uppercase tracking-[0.16em] text-amber">
                <ShieldCheck className="h-3.5 w-3.5" />
                Takes 30 seconds
              </span>
              <h2 className="mt-6 text-3xl font-bold tracking-[-0.035em] text-white sm:text-5xl sm:leading-[1.05]">
                Give your server
                <br />
                <span className="text-gradient">a guardian.</span>
              </h2>
              <p className="mx-auto mt-4 max-w-lg text-[14.5px] leading-7 text-zinc-400">
                Add Kyvo, run one command, and get back to your community. The boring parts are
                handled.
              </p>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <a href={site.invite} target="_blank" rel="noreferrer" className="btn-primary group w-full sm:w-auto">
                  <DiscordIcon className="h-4 w-4" />
                  Add to Discord
                  <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                </a>
                <a href={site.support} target="_blank" rel="noreferrer" className="btn-ghost w-full sm:w-auto">
                  Join support
                </a>
              </div>
              <p className="mt-5 text-[11px] text-zinc-600">
                Needs Manage Server · Free core features · No credit card
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
