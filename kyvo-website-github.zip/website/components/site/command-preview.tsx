'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import {
  ArrowRight,
  Check,
  ChevronRight,
  Command,
  Copy,
  Search,
  Sparkles,
} from 'lucide-react';
import { categoryIcon } from '@/lib/icons';
import type { CommandCategory } from '@/lib/types';
import { cn } from '@/lib/utils';

const popularNames = [
  'antinuke enable',
  'automod enable',
  'ban',
  'ticket setup',
  'gstart',
  'play',
  'ai',
  'leveling rank',
  'antiraid',
  'backup create',
];

type Row = {
  command: string;
  category: CommandCategory;
  group: string;
};

export function CommandPreview({
  categories,
  total,
}: {
  categories: CommandCategory[];
  total: number;
}) {
  const [query, setQuery] = useState('');
  const [active, setActive] = useState<string>('all');
  const [copied, setCopied] = useState<string | null>(null);

  const allRows = useMemo<Row[]>(
    () =>
      categories.flatMap((category) =>
        category.groups.flatMap((group) =>
          group.commands.map((command) => ({ command, category, group: group.name })),
        ),
      ),
    [categories],
  );

  const popularRows = useMemo(
    () =>
      popularNames
        .map((name) => allRows.find((row) => row.command === name))
        .filter((row): row is Row => Boolean(row)),
    [allRows],
  );

  const rows = useMemo(() => {
    const term = query.trim().toLowerCase();
    let base = term
      ? allRows.filter(
          (row) =>
            row.command.toLowerCase().includes(term) ||
            row.category.name.toLowerCase().includes(term) ||
            row.group.toLowerCase().includes(term),
        )
      : active === 'all'
        ? popularRows
        : allRows.filter((row) => row.category.id === active);

    if (active !== 'all') base = base.filter((row) => row.category.id === active);
    return base.slice(0, 9);
  }, [active, allRows, popularRows, query]);

  const copy = async (command: string) => {
    try {
      await navigator.clipboard.writeText(`/${command}`);
      setCopied(command);
      window.setTimeout(() => setCopied((value) => (value === command ? null : value)), 1600);
    } catch {
      setCopied(null);
    }
  };

  const ActiveIcon = active === 'all' ? Command : categoryIcon(categories.find((c) => c.id === active)?.icon || 'general');

  return (
    <section className="relative py-24">
      <div className="container-page">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="eyebrow">
              <Command className="h-3.5 w-3.5 text-amber" />
              Command library
            </p>
            <h2 className="mt-5 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.08]">
              {total} commands.
              <span className="text-zinc-500"> Zero guesswork.</span>
            </h2>
            <p className="mt-4 max-w-xl text-[15px] leading-7 text-zinc-400">
              Search the real command library below, or open the full explorer for categories,
              aliases and one-click copying.
            </p>
          </div>
          <Link href="/commands" className="btn-ghost group shrink-0">
            Open command explorer
            <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
          </Link>
        </div>

        <div className="card mt-10 overflow-hidden">
          <div className="flex flex-col gap-3 border-b border-white/[0.07] p-4 sm:flex-row sm:items-center sm:p-5">
            <div className="flex h-11 flex-1 items-center gap-2.5 rounded-2xl border border-white/[0.08] bg-black/30 px-3.5 transition focus-within:border-amber/40 focus-within:bg-black/45">
              <Search className="h-4 w-4 shrink-0 text-zinc-500" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder={`Search ${total} commands — try “antinuke”, “play” or “ticket”`}
                aria-label="Search commands"
                className="h-full w-full bg-transparent text-[13px] text-white placeholder:text-zinc-600 focus:outline-none"
              />
              <kbd className="hidden rounded border border-white/10 bg-white/[0.04] px-1.5 py-0.5 font-mono text-[9px] text-zinc-500 sm:block">
                /
              </kbd>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-zinc-500">
              <Sparkles className="h-3.5 w-3.5 text-amber" />
              Live from Kyvo&apos;s help registry
            </div>
          </div>

          <div className="grid lg:grid-cols-[210px_1fr]">
            <aside className="hidden border-r border-white/[0.07] p-3 lg:block">
              <button
                type="button"
                onClick={() => setActive('all')}
                className={cn(
                  'flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-[12.5px] transition',
                  active === 'all'
                    ? 'bg-amber/10 text-amber-soft'
                    : 'text-zinc-500 hover:bg-white/[0.04] hover:text-zinc-200',
                )}
              >
                <Command className="h-4 w-4" />
                Popular
              </button>
              <div className="mt-1 max-h-[330px] space-y-0.5 overflow-y-auto scroll-thin pr-1">
                {categories.map((category) => {
                  const Icon = categoryIcon(category.icon);
                  return (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => setActive(category.id)}
                      className={cn(
                        'flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-[12.5px] transition',
                        active === category.id
                          ? 'bg-amber/10 text-amber-soft'
                          : 'text-zinc-500 hover:bg-white/[0.04] hover:text-zinc-200',
                      )}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span className="truncate">{category.name}</span>
                      <span className="ml-auto font-mono text-[9px] text-zinc-600">{category.count}</span>
                    </button>
                  );
                })}
              </div>
            </aside>

            <div className="min-w-0 p-4 sm:p-5">
              <div className="mb-3 flex items-center justify-between gap-3">
                <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-500">
                  <ActiveIcon className="h-3.5 w-3.5 text-amber" />
                  {query
                    ? `${rows.length} result${rows.length === 1 ? '' : 's'}`
                    : active === 'all'
                      ? 'Popular commands'
                      : categories.find((category) => category.id === active)?.name}
                </p>
                <span className="font-mono text-[10px] text-zinc-600">{total} total</span>
              </div>

              <div className="mb-3 flex gap-1.5 overflow-x-auto pb-1 scroll-thin lg:hidden">
                <button
                  type="button"
                  onClick={() => setActive('all')}
                  className={cn(
                    'shrink-0 rounded-full border px-3 py-1.5 text-[11px] transition',
                    active === 'all'
                      ? 'border-amber/30 bg-amber/10 text-amber-soft'
                      : 'border-white/[0.08] text-zinc-500',
                  )}
                >
                  Popular
                </button>
                {categories.map((category) => (
                  <button
                    key={category.id}
                    type="button"
                    onClick={() => setActive(category.id)}
                    className={cn(
                      'shrink-0 rounded-full border px-3 py-1.5 text-[11px] transition',
                      active === category.id
                        ? 'border-amber/30 bg-amber/10 text-amber-soft'
                        : 'border-white/[0.08] text-zinc-500',
                    )}
                  >
                    {category.name}
                  </button>
                ))}
              </div>

              <div className="space-y-1">
                {rows.length === 0 && (
                  <div className="rounded-2xl border border-dashed border-white/10 px-4 py-10 text-center">
                    <p className="text-sm text-zinc-400">No command matches “{query}”.</p>
                    <p className="mt-1 text-[12px] text-zinc-600">
                      Try a broader term like “mod”, “music” or “ticket”.
                    </p>
                  </div>
                )}

                {rows.map((row) => {
                  const Icon = categoryIcon(row.category.icon);
                  const isCopied = copied === row.command;
                  return (
                    <div
                      key={`${row.category.id}-${row.command}`}
                      className="group flex items-center gap-3 rounded-xl border border-transparent px-2.5 py-2.5 transition hover:border-white/[0.07] hover:bg-white/[0.025]"
                    >
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/[0.07] bg-white/[0.025] text-zinc-500 group-hover:text-amber">
                        <Icon className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <code className="block truncate font-mono text-[12.5px] text-zinc-200">
                          /{row.command}
                        </code>
                        <p className="truncate text-[10px] text-zinc-600">
                          {row.category.name} · {row.group}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => copy(row.command)}
                        aria-label={`Copy /${row.command}`}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/[0.07] bg-white/[0.02] text-zinc-500 opacity-0 transition hover:text-amber group-hover:opacity-100 focus:opacity-100"
                      >
                        {isCopied ? <Check className="h-3.5 w-3.5 text-mint" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                      <ChevronRight className="hidden h-4 w-4 shrink-0 text-zinc-700 sm:block" />
                    </div>
                  );
                })}
              </div>

              <div className="mt-4 flex flex-col gap-2 border-t border-white/[0.06] pt-4 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-[11px] text-zinc-600">
                  Slash commands where available · prefix <code className="font-mono text-zinc-400">,</code>
                </p>
                <Link
                  href="/commands"
                  className="inline-flex items-center gap-1.5 text-[12px] font-medium text-amber transition hover:text-amber-soft"
                >
                  View all {total}
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
