import Link from 'next/link';
import {
  ArrowRight,
  Ban,
  Bot,
  FileWarning,
  LockKeyhole,
  Radio,
  ShieldCheck,
  ShieldHalf,
  Siren,
  Webhook,
} from 'lucide-react';
import { Reveal } from './reveal';

const protections = [
  {
    icon: Ban,
    title: 'Mass ban & kick shield',
    copy: 'Destructive moderation is frozen the moment it crosses the threshold.',
  },
  {
    icon: Webhook,
    title: 'Anti-webhook & anti-bot',
    copy: 'New webhooks and bot adds are blocked unless you whitelisted them.',
  },
  {
    icon: FileWarning,
    title: 'Channel & role guards',
    copy: 'Deletes, permission rewrites and mass role edits are restored instantly.',
  },
  {
    icon: Siren,
    title: 'Emergency lockdown',
    copy: 'One command locks the server down and preserves the audit trail.',
  },
];

const orbit = [
  { label: 'Anti-ban', className: 'left-0 top-[22%]' },
  { label: 'Anti-raid', className: 'right-0 top-[18%]' },
  { label: 'Anti-bot', className: 'left-[2%] bottom-[18%]' },
  { label: 'Anti-webhook', className: 'right-[0%] bottom-[22%]' },
];

export function Security() {
  return (
    <section id="security" className="relative scroll-mt-24 py-24">
      <div className="container-page">
        <Reveal>
          <div className="noise relative overflow-hidden rounded-[32px] border border-white/[0.08] bg-gradient-to-br from-[#121014] via-ink-900 to-[#0d0a06] p-6 shadow-card sm:p-10 lg:p-12">
            <div aria-hidden className="absolute inset-0 grid-bg opacity-40" />
            <div aria-hidden className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-danger/[0.10] blur-[110px]" />
            <div aria-hidden className="absolute -bottom-40 left-1/4 h-80 w-80 rounded-full bg-amber/[0.07] blur-[100px]" />

            <div className="relative grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr]">
              <div>
                <p className="eyebrow border-danger/20 bg-danger/[0.06] text-danger/90">
                  <ShieldHalf className="h-3.5 w-3.5" />
                  Security first
                </p>
                <h2 className="mt-5 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.08]">
                  Raids end <span className="text-gradient">before they start.</span>
                </h2>
                <p className="mt-4 max-w-xl text-[15px] leading-7 text-zinc-400">
                  Kyvo doesn&apos;t wait for the damage report. It watches privileged actions across
                  your server and steps in within milliseconds, then tells you exactly what happened.
                </p>

                <div className="mt-8 grid gap-x-6 gap-y-5 sm:grid-cols-2">
                  {protections.map((item) => (
                    <div key={item.title} className="flex gap-3">
                      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-white/[0.08] bg-white/[0.03] text-amber">
                        <item.icon className="h-4 w-4" />
                      </span>
                      <div>
                        <h3 className="text-[13.5px] font-semibold text-white">{item.title}</h3>
                        <p className="mt-1 text-[12px] leading-5 text-zinc-500">{item.copy}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-9 flex flex-wrap items-center gap-3">
                  <Link href="/commands#security" className="btn-primary group">
                    See security commands
                    <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                  </Link>
                  <span className="text-[11.5px] text-zinc-500">
                    Includes whitelist, trusted users and audit logs.
                  </span>
                </div>
              </div>

              <div className="relative mx-auto aspect-square w-full max-w-[420px]">
                <div aria-hidden className="absolute inset-0 rounded-full bg-radial-amber opacity-60 blur-2xl" />
                <div aria-hidden className="absolute inset-[7%] rounded-full border border-white/[0.06]" />
                <div aria-hidden className="absolute inset-[17%] rounded-full border border-dashed border-amber/20 animate-[spin_50s_linear_infinite]" />
                <div aria-hidden className="absolute inset-[28%] rounded-full border border-white/[0.07]" />
                <div aria-hidden className="absolute inset-[28%] rounded-full border border-amber/10 animate-[spin_35s_linear_infinite_reverse]" />

                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative flex h-36 w-36 flex-col items-center justify-center rounded-[32px] border border-amber/25 bg-ink-900/90 shadow-glow backdrop-blur-xl">
                    <div aria-hidden className="absolute inset-0 overflow-hidden rounded-[32px]">
                      <div className="absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-amber/20 to-transparent animate-scan" />
                    </div>
                    <ShieldCheck className="h-12 w-12 text-amber" strokeWidth={1.6} />
                    <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.2em] text-amber/80">
                      Armed
                    </p>
                  </div>
                </div>

                {orbit.map((node, index) => (
                  <div
                    key={node.label}
                    className={`absolute ${node.className} flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-ink-850/90 px-2.5 py-1.5 text-[10px] font-medium text-zinc-400 shadow-lg backdrop-blur-md`}
                  >
                    <span className={`h-1.5 w-1.5 rounded-full ${index % 2 ? 'bg-amber' : 'bg-mint'}`} />
                    {node.label}
                  </div>
                ))}

                <div className="absolute left-1/2 top-[6%] flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-white/[0.08] bg-ink-850/90 px-3 py-1.5 text-[10px] text-zinc-400 backdrop-blur-md">
                  <LockKeyhole className="h-3 w-3 text-mint" />
                  0 trusted permissions
                </div>
                <div className="absolute bottom-[4%] left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-white/[0.08] bg-ink-850/90 px-3 py-1.5 text-[10px] text-zinc-400 backdrop-blur-md">
                  <Radio className="h-3 w-3 text-amber" />
                  live audit stream
                </div>
              </div>
            </div>

            <div className="relative mt-10 grid gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.06] sm:grid-cols-3">
              {[
                { value: '12', label: 'Guard modules' },
                { value: '0.2s', label: 'Average response' },
                { value: '24/7', label: 'Coverage' },
              ].map((stat) => (
                <div key={stat.label} className="bg-ink-900/80 px-5 py-4 text-center">
                  <p className="text-xl font-bold text-white">{stat.value}</p>
                  <p className="mt-0.5 text-[10.5px] uppercase tracking-[0.14em] text-zinc-500">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            { icon: Bot, title: 'Whitelist control', copy: 'Only the people you trust can touch the guard.' },
            { icon: ShieldCheck, title: 'Restore, not just block', copy: 'Permissions and channels are rebuilt automatically.' },
            { icon: Siren, title: 'Clear audit trail', copy: 'Every action lands in your log channel with context.' },
          ].map((item, index) => (
            <Reveal key={item.title} delay={index * 70}>
              <div className="card p-5">
                <item.icon className="h-5 w-5 text-amber" />
                <h3 className="mt-4 text-[14px] font-semibold text-white">{item.title}</h3>
                <p className="mt-1.5 text-[12.5px] leading-5 text-zinc-500">{item.copy}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
