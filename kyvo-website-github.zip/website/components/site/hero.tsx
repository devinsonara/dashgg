import Link from 'next/link';
import {
  ArrowRight,
  BadgeCheck,
  Check,
  ChevronRight,
  LockKeyhole,
  Music2,
  Pause,
  ShieldCheck,
  SkipForward,
  Sparkles,
  Terminal,
  Volume2,
  Zap,
} from 'lucide-react';
import { Reveal } from './reveal';
import { site } from '@/lib/site';
import { totalCommands } from '@/lib/commands';

const stats = [
  { value: `${totalCommands}`, label: 'Commands' },
  { value: '20', label: 'Modules' },
  { value: '12', label: 'Anti-nuke guards' },
  { value: '24/7', label: 'Protection' },
];

function HeroConsole() {
  return (
    <div className="relative mx-auto w-full max-w-[540px] lg:max-w-none">
      <div
        aria-hidden
        className="absolute -inset-10 -z-10 rounded-full bg-radial-amber opacity-70 blur-2xl"
      />
      <div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-10 h-[560px] w-[560px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-amber/10"
      />
      <div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-10 h-[440px] w-[440px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-amber/15 animate-[spin_60s_linear_infinite]"
      />

      <div className="animate-float-slow">
        <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-ink-900/90 p-2 shadow-[0_40px_120px_-30px_rgba(0,0,0,.9)] backdrop-blur-xl">
          <div className="flex items-center justify-between rounded-2xl border border-white/[0.06] bg-black/30 px-3 py-2">
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-[#FF5F57]" />
              <span className="h-2 w-2 rounded-full bg-[#FEBC2E]" />
              <span className="h-2 w-2 rounded-full bg-[#28C840]" />
            </div>
            <div className="inline-flex items-center gap-1.5 rounded-md border border-white/[0.06] bg-white/[0.03] px-2.5 py-1 font-mono text-[10px] text-zinc-500">
              <Terminal className="h-3 w-3 text-amber/80" />
              kyvo://command-center
            </div>
            <LockKeyhole className="h-3.5 w-3.5 text-zinc-600" />
          </div>

          <div className="p-3.5 sm:p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-amber-soft to-amber-deep text-lg font-black text-ink-950 shadow-glow-sm">
                K
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="truncate text-sm font-semibold text-white">Kyvo</p>
                  <BadgeCheck className="h-4 w-4 text-amber" />
                  <span className="rounded bg-discord/15 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-[#8f98ff]">
                    App
                  </span>
                </div>
                <p className="text-[11px] text-zinc-500">
                  <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-mint align-middle" />
                  Online · guarding 24/7
                </p>
              </div>
              <div className="ml-auto hidden items-center gap-1 rounded-full border border-white/[0.06] bg-white/[0.03] px-2 py-1 text-[10px] text-zinc-500 sm:flex">
                <Zap className="h-3 w-3 text-amber" />
                42ms
              </div>
            </div>

            <div className="mt-4 overflow-hidden rounded-2xl border border-white/[0.07] bg-gradient-to-b from-white/[0.04] to-transparent">
              <div className="border-l-2 border-amber p-3.5">
                <div className="flex items-center justify-between gap-3">
                  <p className="flex items-center gap-2 text-[13px] font-semibold text-white">
                    <ShieldCheck className="h-4 w-4 text-amber" />
                    Security sweep complete
                  </p>
                  <span className="rounded-full border border-mint/20 bg-mint/10 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-mint">
                    Secure
                  </span>
                </div>
                <p className="mt-1 text-[11px] text-zinc-500">12 modules armed · 0 threats detected</p>

                <div className="mt-3.5 space-y-2.5">
                  {[
                    { label: 'Antinuke', value: 100 },
                    { label: 'Automod', value: 98 },
                    { label: 'Permission audit', value: 94 },
                  ].map((item) => (
                    <div key={item.label}>
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-zinc-500">{item.label}</span>
                        <span className="font-mono text-zinc-400">{item.value}%</span>
                      </div>
                      <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/[0.07]">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-amber-deep to-amber-soft"
                          style={{ width: `${item.value}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-3 flex items-center gap-3 border-t border-white/[0.06] pt-2.5 text-[9px] text-zinc-600">
                  <span className="inline-flex items-center gap-1">
                    <Check className="h-3 w-3 text-mint" /> Anti-webhook
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Check className="h-3 w-3 text-mint" /> Anti-raid
                  </span>
                  <span className="ml-auto">just now</span>
                </div>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-3">
              <div className="rounded-2xl border border-white/[0.07] bg-white/[0.025] p-3">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#8844EE]/15 text-[#b58cff]">
                    <Music2 className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-semibold text-white">Midnight Drive</p>
                    <p className="truncate text-[9px] text-zinc-500">Kyvo Radio · queue 4</p>
                  </div>
                </div>
                <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-white/[0.07]">
                  <div className="h-full w-2/3 rounded-full bg-gradient-to-r from-[#8844EE] to-[#c7a4ff]" />
                </div>
                <div className="mt-2 flex items-center justify-between text-zinc-500">
                  <Volume2 className="h-3 w-3" />
                  <div className="flex items-center gap-2">
                    <SkipForward className="h-3 w-3" />
                    <Pause className="h-3.5 w-3.5 text-white" />
                  </div>
                  <span className="font-mono text-[9px]">2:14</span>
                </div>
              </div>

              <div className="rounded-2xl border border-white/[0.07] bg-white/[0.025] p-3">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber/10 text-amber">
                    <Sparkles className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-semibold text-white">Level up</p>
                    <p className="truncate text-[9px] text-zinc-500">@member reached 42</p>
                  </div>
                </div>
                <div className="mt-2.5 flex items-end gap-1">
                  {[28, 42, 34, 58, 46, 70, 62, 84, 74, 96].map((height, index) => (
                    <span
                      key={index}
                      className="w-full rounded-sm bg-gradient-to-t from-amber/20 to-amber/80"
                      style={{ height: `${height * 0.34}px` }}
                    />
                  ))}
                </div>
                <p className="mt-1.5 text-[9px] text-zinc-600">+240 XP this week</p>
              </div>
            </div>
          </div>

          <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-amber/[0.06] to-transparent" />
        </div>
      </div>

      <div className="absolute -bottom-7 -left-6 hidden animate-float items-center gap-2 rounded-2xl border border-white/10 bg-ink-850/95 px-3 py-2 shadow-xl backdrop-blur-xl xl:flex">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-danger/15 text-danger">
          <ShieldCheck className="h-4 w-4" />
        </span>
        <div>
          <p className="text-[10px] font-semibold text-white">Threat blocked</p>
          <p className="text-[9px] text-zinc-500">mass ban · 0.2s</p>
        </div>
      </div>

      <div className="absolute -bottom-7 -right-4 hidden animate-float items-center gap-2 rounded-2xl border border-white/10 bg-ink-850/95 px-3 py-2 shadow-xl backdrop-blur-xl [animation-delay:1.5s] xl:flex">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-mint/15 text-mint">
          <LockKeyhole className="h-4 w-4" />
        </span>
        <div>
          <p className="text-[10px] font-semibold text-white">Channel secured</p>
          <p className="text-[9px] text-zinc-500">permissions restored</p>
        </div>
      </div>
    </div>
  );
}

export function Hero() {
  return (
    <section className="relative overflow-hidden pb-16 pt-32 sm:pt-36 lg:pb-24 lg:pt-40">
      <div className="container-page">
        <div className="grid items-center gap-14 lg:grid-cols-[1.02fr_0.98fr] lg:gap-10">
          <div>
            <Reveal>
              <a
                href="#security"
                className="eyebrow transition hover:border-amber/30 hover:text-zinc-200"
              >
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-amber" />
                </span>
                New · AI chat + 24/7 music
                <ChevronRight className="h-3 w-3" />
              </a>
            </Reveal>

            <Reveal delay={80}>
              <h1 className="mt-6 text-[2.65rem] font-extrabold leading-[1.02] tracking-[-0.045em] text-white sm:text-6xl lg:text-[4.4rem]">
                Your server&apos;s
                <br />
                <span className="text-gradient">silent guardian.</span>
              </h1>
            </Reveal>

            <Reveal delay={140}>
              <p className="mt-6 max-w-xl text-[15.5px] leading-7 text-zinc-400 sm:text-base">
                Kyvo watches the doors, stops the raids, runs the music, and keeps your
                community moving. <span className="text-zinc-200">516 commands, one quiet bot.</span>{' '}
                No clutter. No chaos. No drama.
              </p>
            </Reveal>

            <Reveal delay={200}>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
                <a href={site.invite} target="_blank" rel="noreferrer" className="btn-primary group">
                  Add to Discord
                  <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                </a>
                <Link href="/commands" className="btn-ghost group">
                  Browse commands
                  <span className="rounded-full bg-white/10 px-1.5 py-0.5 font-mono text-[10px] text-zinc-300">
                    {totalCommands}
                  </span>
                </Link>
              </div>
            </Reveal>

            <Reveal delay={260}>
              <div className="mt-10 grid max-w-xl grid-cols-2 gap-x-6 gap-y-5 border-t border-white/[0.07] pt-7 sm:grid-cols-4">
                {stats.map((stat) => (
                  <div key={stat.label}>
                    <p className="text-2xl font-bold tracking-tight text-white">
                      {stat.value}
                      <span className="text-amber">.</span>
                    </p>
                    <p className="mt-0.5 text-[11px] uppercase tracking-[0.14em] text-zinc-500">
                      {stat.label}
                    </p>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={320}>
              <div className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-2 text-[12px] text-zinc-500">
                <span className="inline-flex items-center gap-1.5">
                  <Check className="h-3.5 w-3.5 text-mint" /> Free core features
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Check className="h-3.5 w-3.5 text-mint" /> Setup in under a minute
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Check className="h-3.5 w-3.5 text-mint" /> No credit card
                </span>
              </div>
            </Reveal>
          </div>

          <Reveal delay={220} className="lg:pl-4">
            <HeroConsole />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
