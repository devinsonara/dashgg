import Link from 'next/link';
import {
  ArrowUpRight,
  AudioLines,
  Pause,
  Repeat2,
  Shuffle,
  SkipBack,
  SkipForward,
  Sparkles,
  Volume2,
} from 'lucide-react';
import { Reveal } from './reveal';

const queue = [
  { title: 'Midnight Drive', artist: 'Kyvo Radio', duration: '3:42', active: true },
  { title: 'Neon Skyline', artist: 'Nova Waves', duration: '2:58', active: false },
  { title: 'Slow Motion', artist: 'Ari Lane', duration: '4:06', active: false },
];

const games = [
  { emoji: '♟', title: 'Chess', copy: 'Full games with buttons' },
  { emoji: '🟩', title: 'Wordle', copy: 'Daily word battles' },
  { emoji: '🔢', title: '2048', copy: 'Swipe-free tile runs' },
  { emoji: '⭕', title: 'Tic-tac-toe', copy: 'Challenge anyone' },
];

export function Showcase() {
  return (
    <section className="relative py-24">
      <div className="container-page">
        <Reveal className="max-w-2xl">
          <p className="eyebrow">
            <Sparkles className="h-3.5 w-3.5 text-amber" />
            The fun stuff
          </p>
          <h2 className="mt-5 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.08]">
            More than moderation.
            <br />
            <span className="text-zinc-500">Less than a pile of bots.</span>
          </h2>
          <p className="mt-4 max-w-xl text-[15px] leading-7 text-zinc-400">
            Your community doesn&apos;t live in a control panel. Give them music that works, an AI
            that knows your rules, and games worth playing.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-4 lg:grid-cols-2">
          <Reveal>
            <article className="card flex h-full flex-col p-6 sm:p-8">
              <div className="flex items-center justify-between">
                <span className="icon-tile">
                  <AudioLines className="h-5 w-5" />
                </span>
                <span className="rounded-full border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.14em] text-zinc-500">
                  Music
                </span>
              </div>
              <h3 className="mt-5 text-xl font-semibold tracking-[-0.02em] text-white">
                A player that doesn&apos;t skip.
              </h3>
              <p className="mt-2 text-[13.5px] leading-6 text-zinc-400">
                YouTube, SoundCloud and direct links. Queue management, audio filters, 24/7 mode and
                Last.fm charts — all from slash commands.
              </p>

              <div className="mt-6 rounded-2xl border border-white/[0.07] bg-black/25 p-4">
                <div className="flex items-center gap-4">
                  <div className="relative flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-[#8844EE] via-[#5b2ba8] to-[#1d1030]">
                    <div className="absolute inset-0 opacity-40 mix-blend-overlay grid-bg" />
                    <AudioLines className="relative h-7 w-7 text-white/90" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-white">Midnight Drive</p>
                    <p className="truncate text-[11px] text-zinc-500">Kyvo Radio · requested by @you</p>
                    <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-white/[0.08]">
                      <div className="h-full w-[62%] rounded-full bg-gradient-to-r from-amber-deep to-amber-soft" />
                    </div>
                    <div className="mt-1.5 flex justify-between font-mono text-[9px] text-zinc-600">
                      <span>2:18</span>
                      <span>3:42</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between text-zinc-500">
                  <div className="flex items-center gap-3">
                    <Shuffle className="h-3.5 w-3.5" />
                    <SkipBack className="h-4 w-4" />
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-amber text-ink-950">
                      <Pause className="h-4 w-4" />
                    </span>
                    <SkipForward className="h-4 w-4" />
                    <Repeat2 className="h-3.5 w-3.5" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Volume2 className="h-3.5 w-3.5" />
                    <div className="h-1 w-16 overflow-hidden rounded-full bg-white/[0.08]">
                      <div className="h-full w-2/3 rounded-full bg-zinc-400" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-1.5">
                {queue.slice(1).map((track) => (
                  <div
                    key={track.title}
                    className="flex items-center gap-3 rounded-xl px-2 py-2 text-[11.5px] transition hover:bg-white/[0.03]"
                  >
                    <span className="w-4 font-mono text-[9px] text-zinc-600">02</span>
                    <span className="truncate text-zinc-400">{track.title}</span>
                    <span className="ml-auto font-mono text-[9px] text-zinc-600">{track.duration}</span>
                  </div>
                ))}
              </div>
            </article>
          </Reveal>

          <Reveal delay={100}>
            <article className="card flex h-full flex-col p-6 sm:p-8">
              <div className="flex items-center justify-between">
                <span className="icon-tile">
                  <Sparkles className="h-5 w-5" />
                </span>
                <span className="rounded-full border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.14em] text-zinc-500">
                  AI
                </span>
              </div>
              <h3 className="mt-5 text-xl font-semibold tracking-[-0.02em] text-white">
                An AI that knows your house rules.
              </h3>
              <p className="mt-2 text-[13.5px] leading-6 text-zinc-400">
                Chat naturally, answer FAQs with custom replies, and give the AI its own channels.
                It remembers the context — you stay in control.
              </p>

              <div className="mt-6 flex-1 space-y-2.5 rounded-2xl border border-white/[0.07] bg-black/25 p-4">
                <div className="flex items-center gap-2 border-b border-white/[0.06] pb-3">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-amber-soft to-amber-deep text-[11px] font-black text-ink-950">
                    K
                  </span>
                  <div>
                    <p className="text-[11.5px] font-semibold text-white">Kyvo AI</p>
                    <p className="text-[9px] text-mint">online</p>
                  </div>
                  <span className="ml-auto rounded-full border border-white/[0.08] px-2 py-0.5 font-mono text-[9px] text-zinc-500">
                    #general
                  </span>
                </div>

                <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-md bg-amber/15 px-3.5 py-2.5 text-[12px] text-amber-soft">
                  Can I post my YouTube video here?
                </div>
                <div className="w-fit max-w-[92%] rounded-2xl rounded-bl-md border border-white/[0.06] bg-white/[0.04] px-3.5 py-2.5 text-[12px] leading-relaxed text-zinc-300">
                  Not in #general — self-promo belongs in{' '}
                  <span className="rounded bg-black/40 px-1 font-mono text-[11px] text-amber">#showcase</span>
                  . Want me to drop the full rule?
                </div>
                <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-md bg-amber/15 px-3.5 py-2.5 text-[12px] text-amber-soft">
                  yes please
                </div>
                <div className="flex w-fit items-center gap-1 rounded-2xl rounded-bl-md border border-white/[0.06] bg-white/[0.04] px-3.5 py-3">
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500 [animation-delay:0ms]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500 [animation-delay:120ms]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-500 [animation-delay:240ms]" />
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-1.5">
                {['AI chat', 'Auto channels', 'Custom replies', 'Memory control'].map((chip) => (
                  <span
                    key={chip}
                    className="rounded-md border border-white/[0.07] bg-white/[0.025] px-2 py-0.5 text-[10.5px] text-zinc-500"
                  >
                    {chip}
                  </span>
                ))}
              </div>
            </article>
          </Reveal>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {games.map((game, index) => (
            <Reveal key={game.title} delay={index * 60}>
              <div className="card card-hover flex items-center gap-3 p-4">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/[0.08] bg-white/[0.03] text-lg">
                  {game.emoji}
                </span>
                <div>
                  <p className="text-[13px] font-semibold text-white">{game.title}</p>
                  <p className="text-[10.5px] text-zinc-500">{game.copy}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-8 flex justify-center">
          <Link href="/commands" className="btn-ghost group">
            Browse the full command list
            <ArrowUpRight className="h-4 w-4 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
