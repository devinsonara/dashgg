import { HelpCircle, Minus, Plus } from 'lucide-react';
import { Reveal } from './reveal';
import { site } from '@/lib/site';
import { totalCommands } from '@/lib/commands';

const faqs = [
  {
    q: 'Is Kyvo really free?',
    a: `Yes. Antinuke, automod, moderation, tickets, giveaways, leveling, music, AI chat and all ${totalCommands} commands are available on the free tier. Premium adds backups, security scans, locked roles and custom bot branding.`,
  },
  {
    q: 'How do I add Kyvo to my server?',
    a: 'Tap “Add Kyvo” and pick the server you manage. You need the Manage Server permission. After that, run /help or ,help and you are ready — no setup wizard, no dashboard required.',
  },
  {
    q: 'Does it use slash commands or a prefix?',
    a: 'Both. Slash commands are registered globally, and the default prefix is a comma (,). Servers can change the prefix with the prefix command. The website displays slash commands by default because they are easiest to discover.',
  },
  {
    q: 'What permissions does Kyvo need?',
    a: 'For full antinuke protection, Kyvo needs administrator so it can restore permissions, channels and roles during an incident. If you prefer granular permissions, the moderation, music and utility features work with a narrower set.',
  },
  {
    q: 'Can I change settings from this website?',
    a: 'The dashboard is read-only in this release: you can sign in with Discord, see the servers you manage and review their overview. Live module toggles are the next phase and will be enabled once the bot API is connected.',
  },
  {
    q: 'How is my data handled?',
    a: 'Kyvo stores server configuration in its own database. The website stores your Discord profile and manageable server list in an encrypted, http-only session cookie. It does not read or store your messages.',
  },
  {
    q: 'Where do I get help?',
    a: 'Join the support server from the footer or the navigation bar. For command-specific help, run /help in Discord — it stays in Discord and is updated with the bot.',
  },
  {
    q: 'Can I use Kyvo in multiple servers?',
    a: 'Yes. Invite it to as many servers as you manage. Each server has independent settings, prefixes, logs and premium status.',
  },
];

export function FAQ() {
  return (
    <section className="relative py-24">
      <div className="container-page">
        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow">
              <HelpCircle className="h-3.5 w-3.5 text-amber" />
              FAQ
            </p>
            <h2 className="mt-5 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl lg:leading-[1.1]">
              Questions,
              <br />
              <span className="text-zinc-500">answered.</span>
            </h2>
            <p className="mt-4 max-w-sm text-[14px] leading-7 text-zinc-500">
              Still stuck? The support server is one click away — real people, no ticket maze.
            </p>
            <a
              href={site.support}
              target="_blank"
              rel="noreferrer"
              className="btn-ghost mt-6"
            >
              Join the support server
            </a>
          </Reveal>

          <Reveal delay={100}>
            <div className="divide-y divide-white/[0.07] overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.015]">
              {faqs.map((faq) => (
                <details key={faq.q} className="group">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-6 px-5 py-4 transition hover:bg-white/[0.025] sm:px-6 sm:py-5">
                    <span className="text-[13.5px] font-medium text-zinc-200">{faq.q}</span>
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.03] text-zinc-500 transition group-open:border-amber/30 group-open:text-amber">
                      <Plus className="h-3.5 w-3.5 group-open:hidden" />
                      <Minus className="hidden h-3.5 w-3.5 group-open:block" />
                    </span>
                  </summary>
                  <div className="px-5 pb-5 text-[13px] leading-6 text-zinc-500 sm:px-6 sm:pb-6">
                    {faq.a}
                  </div>
                </details>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
