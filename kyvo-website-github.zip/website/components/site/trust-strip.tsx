import { ShieldCheck } from 'lucide-react';

const items = [
  'Antinuke',
  'Automod',
  'Moderation',
  'Tickets',
  'Giveaways',
  'Leveling',
  'Music',
  'AI Chat',
  'Voice',
  'Logging',
  'Reaction roles',
  'Invite tracking',
];

export function TrustStrip() {
  return (
    <section aria-label="Kyvo features" className="relative border-y border-white/[0.06] bg-white/[0.012] py-5">
      <div className="container-page">
        <div className="flex items-center gap-6">
          <p className="hidden shrink-0 items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-500 sm:flex">
            <ShieldCheck className="h-3.5 w-3.5 text-amber" />
            One bot. Every layer.
          </p>
          <div className="relative flex-1 overflow-hidden mask-fade-x">
            <div className="flex w-max animate-marquee items-center gap-8 hover:[animation-play-state:paused]">
              {[...items, ...items].map((item, index) => (
                <span
                  key={`${item}-${index}`}
                  className="flex items-center gap-8 whitespace-nowrap text-[13px] font-medium text-zinc-500"
                >
                  {item}
                  <span className="h-1 w-1 rounded-full bg-amber/50" />
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
