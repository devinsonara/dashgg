import Link from 'next/link';
import { ArrowUpRight, Github, MessagesSquare, Twitter } from 'lucide-react';
import { Logo } from '@/components/logo';
import { DiscordIcon } from '@/components/discord-icon';
import { site } from '@/lib/site';

const columns = [
  {
    title: 'Product',
    links: [
      { label: 'Features', href: '/#features' },
      { label: 'Commands', href: '/commands' },
      { label: 'Security', href: '/#security' },
      { label: 'Premium', href: '/#premium' },
    ],
  },
  {
    title: 'Resources',
    links: [
      { label: 'Dashboard', href: '/dashboard' },
      { label: 'Support server', href: site.support, external: true },
      { label: 'Vote on Top.gg', href: site.topgg, external: true },
      { label: 'Status', href: '/status' },
    ],
  },
  {
    title: 'Legal',
    links: [
      { label: 'Privacy policy', href: '/privacy' },
      { label: 'Terms of service', href: '/terms' },
      { label: 'Security', href: '/#security' },
    ],
  },
];

export function Footer() {
  return (
    <footer className="relative mt-24 border-t border-white/[0.07] bg-ink-950/60">
      <div className="container-page py-14">
        <div className="grid gap-12 lg:grid-cols-[1.5fr_2fr]">
          <div>
            <Link href="/" aria-label="Kyvo home">
              <Logo />
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-zinc-500">
              The all-in-one Discord bot for security, moderation, music and community growth.
              Built to disappear into the background — until it&apos;s needed.
            </p>
            <div className="mt-6 flex items-center gap-2.5">
              <a
                href={site.support}
                target="_blank"
                rel="noreferrer"
                aria-label="Join the support server"
                className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-zinc-400 transition hover:border-amber/30 hover:text-amber"
              >
                <DiscordIcon />
              </a>
              <a
                href={site.topgg}
                target="_blank"
                rel="noreferrer"
                aria-label="Vote on Top.gg"
                className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-zinc-400 transition hover:border-amber/30 hover:text-amber"
              >
                <ArrowUpRight className="h-4 w-4" />
              </a>
              {site.twitter && (
                <a
                  href={site.twitter}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Twitter"
                  className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-zinc-400 transition hover:border-amber/30 hover:text-amber"
                >
                  <Twitter className="h-4 w-4" />
                </a>
              )}
              {site.github && (
                <a
                  href={site.github}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="GitHub"
                  className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-zinc-400 transition hover:border-amber/30 hover:text-amber"
                >
                  <Github className="h-4 w-4" />
                </a>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {columns.map((column) => (
              <div key={column.title}>
                <h3 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
                  {column.title}
                </h3>
                <ul className="mt-4 space-y-2.5">
                  {column.links.map((link) => (
                    <li key={link.label}>
                      {'external' in link && link.external ? (
                        <a
                          href={link.href}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-sm text-zinc-400 transition hover:text-white"
                        >
                          {link.label}
                          <ArrowUpRight className="h-3 w-3 opacity-60" />
                        </a>
                      ) : (
                        <Link href={link.href} className="text-sm text-zinc-400 transition hover:text-white">
                          {link.label}
                        </Link>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-white/[0.06] pt-6 text-xs text-zinc-600 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Kyvo. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            <span className="inline-flex items-center gap-2 text-zinc-500">
              <span className="dot" />
              All systems operational
            </span>
            <span className="hidden sm:inline text-zinc-700">•</span>
            <span>Not affiliated with Discord Inc.</span>
            <span className="hidden sm:inline text-zinc-700">•</span>
            <span className="inline-flex items-center gap-1.5">
              <MessagesSquare className="h-3.5 w-3.5" />
              Built for communities
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
