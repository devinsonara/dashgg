import Link from 'next/link';
import {
  ArrowUpRight,
  Bot,
  Check,
  Crown,
  Gamepad2,
  Gift,
  Gavel,
  MessagesSquare,
  Mic,
  Music2,
  ShieldCheck,
  Sparkles,
  Ticket,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Reveal } from './reveal';
import { cn } from '@/lib/utils';

type Feature = {
  icon: LucideIcon;
  title: string;
  description: string;
  span: string;
  chips?: string[];
  visual?: 'security' | 'automod' | 'music' | 'ai';
};

const features: Feature[] = [
  {
    icon: ShieldCheck,
    title: 'Antinuke protection',
    description:
      'Every destructive action is watched in real time. Mass bans, channel deletes, webhook spam and bot adds are stopped before they land.',
    span: 'md:col-span-3',
    chips: ['Anti-ban', 'Anti-webhook', 'Anti-bot', 'Emergency lockdown'],
    visual: 'security',
  },
  {
    icon: Bot,
    title: 'Automod that actually keeps up',
    description:
      'Spam, invites, caps, mass mentions and blacklisted words handled automatically — with per-channel and per-role ignore lists.',
    span: 'md:col-span-3',
    chips: ['Spam', 'Links', 'Invites', 'Bad words'],
    visual: 'automod',
  },
  {
    icon: Gavel,
    title: 'Moderation suite',
    description: 'Ban, kick, mute, warn, purge, snipe and temp roles — with clean logs for every action.',
    span: 'md:col-span-2',
  },
  {
    icon: Ticket,
    title: 'Tickets & applications',
    description: 'Panels, categories, claims, transcripts and staff review buttons out of the box.',
    span: 'md:col-span-2',
  },
  {
    icon: Gift,
    title: 'Giveaways',
    description: 'Scheduled giveaways, requirements, rerolls and a global giveaway system.',
    span: 'md:col-span-2',
  },
  {
    icon: Music2,
    title: 'Music & Last.fm',
    description:
      'Queue, filters, 24/7 mode and now-playing cards. Pair it with Last.fm scrobbles and top charts.',
    span: 'md:col-span-3',
    chips: ['YouTube', 'SoundCloud', 'Filters', '24/7'],
    visual: 'music',
  },
  {
    icon: Sparkles,
    title: 'AI chat, your rules',
    description:
      'Talk to Kyvo, give it auto-chat channels, and add custom replies for the questions your server keeps asking.',
    span: 'md:col-span-3',
    chips: ['AI chat', 'Auto channels', 'Custom replies'],
    visual: 'ai',
  },
  {
    icon: TrendingUp,
    title: 'Leveling & counting',
    description: 'XP, rank cards, leaderboards and a counting game with role rewards.',
    span: 'md:col-span-2',
  },
  {
    icon: Gamepad2,
    title: 'Games',
    description: 'Chess, Wordle, 2048, tic-tac-toe, connect four, battleship and more.',
    span: 'md:col-span-2',
  },
  {
    icon: Users,
    title: 'Roles & onboarding',
    description: 'Autorole, reaction roles, self-roles, verification and join-to-create voice.',
    span: 'md:col-span-2',
  },
  {
    icon: Mic,
    title: 'Voice tools',
    description: 'Voice roles, temporary channels, VC moderation and member controls.',
    span: 'md:col-span-3',
  },
  {
    icon: Crown,
    title: 'Premium extras',
    description: 'Server backups, security scans, locked roles, custom bot profile and 24/7 music.',
    span: 'md:col-span-3',
  },
];

function SecurityVisual() {
  return (
    <div className="mt-5 space-y-2 rounded-2xl border border-white/[0.06] bg-black/25 p-3">
      {[
        ['Mass ban attempt', 'blocked'],
        ['Channel delete spam', 'blocked'],
        ['Webhook creation', 'blocked'],
      ].map(([label, status]) => (
        <div key={label} className="flex items-center justify-between gap-3 text-[11px]">
          <span className="flex items-center gap-2 text-zinc-500">
            <span className="h-1.5 w-1.5 rounded-full bg-danger/80" />
            {label}
          </span>
          <span className="rounded-full border border-mint/20 bg-mint/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-mint">
            {status}
          </span>
        </div>
      ))}
    </div>
  );
}

function AutomodVisual() {
  return (
    <div className="mt-5 flex flex-wrap gap-1.5">
      {['Spam', 'Invites', 'Caps', 'Mentions', 'Links', 'Bad words', 'Emoji spam'].map((item) => (
        <span
          key={item}
          className="rounded-lg border border-white/[0.07] bg-black/25 px-2.5 py-1 text-[10px] font-medium text-zinc-400"
        >
          {item}
        </span>
      ))}
    </div>
  );
}

function MusicVisual() {
  return (
    <div className="mt-5 flex items-end gap-1.5 rounded-2xl border border-white/[0.06] bg-black/25 p-3">
      {[34, 52, 28, 66, 44, 78, 56, 88, 62, 74, 48, 92, 58, 70, 40, 64, 50, 82, 36, 68].map(
        (height, index) => (
          <span
            key={index}
            className="w-full rounded-sm bg-gradient-to-t from-amber/15 to-amber/75"
            style={{ height: `${Math.max(6, height * 0.42)}px` }}
          />
        ),
      )}
    </div>
  );
}

function AiVisual() {
  return (
    <div className="mt-5 space-y-2 rounded-2xl border border-white/[0.06] bg-black/25 p-3">
      <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-md bg-amber/15 px-3 py-2 text-[11px] text-amber-soft">
        What&apos;s our rule on self-promo?
      </div>
      <div className="w-fit max-w-[90%] rounded-2xl rounded-bl-md border border-white/[0.06] bg-white/[0.04] px-3 py-2 text-[11px] leading-relaxed text-zinc-400">
        Rule 4 — no self-promo outside <span className="font-mono text-amber">#showcase</span>. Want me
        to link it?
      </div>
    </div>
  );
}

const visuals = {
  security: SecurityVisual,
  automod: AutomodVisual,
  music: MusicVisual,
  ai: AiVisual,
};

export function Features() {
  return (
    <section id="features" className="relative scroll-mt-24 py-24">
      <div className="container-page">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <Reveal className="max-w-2xl">
            <p className="eyebrow">
              <Zap className="h-3.5 w-3.5 text-amber" />
              One bot. Every job.
            </p>
            <h2 className="mt-5 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.08]">
              Everything your server needs.
              <br />
              <span className="text-zinc-500">Nothing it doesn&apos;t.</span>
            </h2>
            <p className="mt-4 max-w-xl text-[15px] leading-7 text-zinc-400">
              Stop stacking five bots that fight each other. Kyvo covers protection, community and
              entertainment with one clean, fast setup.
            </p>
          </Reveal>

          <Reveal delay={100} className="shrink-0">
            <Link href="/commands" className="btn-ghost group">
              Explore all features
              <ArrowUpRight className="h-4 w-4 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </Link>
          </Reveal>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-6">
          {features.map((feature, index) => {
            const Visual = feature.visual ? visuals[feature.visual] : null;
            return (
              <Reveal
                key={feature.title}
                delay={(index % 3) * 70}
                className={cn('group', feature.span)}
              >
                <article className="card card-hover flex h-full flex-col p-5 sm:p-6">
                  <div
                    aria-hidden
                    className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-amber/[0.07] opacity-0 blur-2xl transition duration-500 group-hover:opacity-100"
                  />
                  <div className="flex items-start justify-between gap-4">
                    <span className="icon-tile">
                      <feature.icon className="h-5 w-5" />
                    </span>
                    <ArrowUpRight className="h-4 w-4 text-zinc-700 transition group-hover:text-amber" />
                  </div>
                  <h3 className="mt-5 text-[17px] font-semibold tracking-[-0.01em] text-white">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-[13.5px] leading-6 text-zinc-400">{feature.description}</p>

                  {feature.chips && (
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {feature.chips.map((chip) => (
                        <span
                          key={chip}
                          className="rounded-md border border-white/[0.07] bg-white/[0.025] px-2 py-0.5 text-[10.5px] text-zinc-500"
                        >
                          {chip}
                        </span>
                      ))}
                    </div>
                  )}

                  {Visual && (
                    <div className="mt-auto">
                      <Visual />
                    </div>
                  )}
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={80}>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[12px] text-zinc-600">
            <span className="inline-flex items-center gap-1.5">
              <Check className="h-3.5 w-3.5 text-mint" /> Slash + prefix commands
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Check className="h-3.5 w-3.5 text-mint" /> Per-server configuration
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Check className="h-3.5 w-3.5 text-mint" /> No setup wizards
            </span>
            <span className="inline-flex items-center gap-1.5">
              <MessagesSquare className="h-3.5 w-3.5" /> Help that stays in Discord
            </span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
