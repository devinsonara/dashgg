import Link from 'next/link';
import { ArrowRight, Check, Crown, Sparkles, X } from 'lucide-react';
import { Reveal } from './reveal';
import { site } from '@/lib/site';
import { totalCommands } from '@/lib/commands';

const free = [
  'Antinuke & automod',
  'Full moderation suite',
  'Tickets & applications',
  'Giveaways & counting',
  'Leveling & rank cards',
  'Music player & queue',
  'AI chat & custom replies',
  `All ${totalCommands} commands`,
];

const premium = [
  'Server backups & restore',
  'Deep security scans',
  'Locked roles & whitelists',
  'Custom bot profile',
  'Music filters & 24/7 mode',
  'Message stats & leaderboards',
  'Premium support',
];

export function Premium() {
  return (
    <section id="premium" className="relative scroll-mt-24 py-24">
      <div className="container-page">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">
            <Crown className="h-3.5 w-3.5 text-amber" />
            Premium
          </p>
          <h2 className="mt-5 text-3xl font-bold tracking-[-0.03em] text-white sm:text-4xl lg:text-[2.9rem] lg:leading-[1.08]">
            Premium where it matters.
            <br />
            <span className="text-zinc-500">Free where it counts.</span>
          </h2>
          <p className="mt-4 text-[15px] leading-7 text-zinc-400">
            The core bot is free forever. Premium adds deeper control for communities that need
            backups, audits and a bot that looks like theirs.
          </p>
        </Reveal>

        <div className="mx-auto mt-12 grid max-w-4xl gap-4 md:grid-cols-2">
          <Reveal>
            <article className="card flex h-full flex-col p-6 sm:p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-500">
                    Core
                  </p>
                  <h3 className="mt-1.5 text-2xl font-bold text-white">Free forever</h3>
                </div>
                <span className="rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1 text-[10.5px] font-medium text-zinc-400">
                  $0
                </span>
              </div>
              <p className="mt-3 text-[13px] leading-6 text-zinc-500">
                Everything a growing server needs to stay safe and active.
              </p>

              <ul className="mt-6 space-y-2.5">
                {free.map((item) => (
                  <li key={item} className="flex items-center gap-2.5 text-[13px] text-zinc-300">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-mint/10">
                      <Check className="h-3 w-3 text-mint" />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>

              <a
                href={site.invite}
                target="_blank"
                rel="noreferrer"
                className="btn-ghost mt-8 w-full"
              >
                Add Kyvo
                <ArrowRight className="h-4 w-4" />
              </a>
            </article>
          </Reveal>

          <Reveal delay={100}>
            <article className="relative flex h-full flex-col overflow-hidden rounded-3xl border border-amber/30 bg-gradient-to-b from-amber/[0.09] to-transparent p-6 shadow-glow sm:p-8">
              <div aria-hidden className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-amber/15 blur-[70px]" />
              <div className="relative flex items-center justify-between">
                <div>
                  <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-amber">
                    <Sparkles className="h-3 w-3" />
                    Premium
                  </p>
                  <h3 className="mt-1.5 text-2xl font-bold text-white">For serious servers</h3>
                </div>
                <span className="rounded-full border border-amber/30 bg-amber/10 px-3 py-1 text-[10.5px] font-semibold text-amber-soft">
                  Redeem code
                </span>
              </div>
              <p className="relative mt-3 text-[13px] leading-6 text-zinc-400">
                Deeper control, recovery and customisation for networks and staff teams.
              </p>

              <ul className="relative mt-6 space-y-2.5">
                {premium.map((item) => (
                  <li key={item} className="flex items-center gap-2.5 text-[13px] text-zinc-200">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber/15">
                      <Check className="h-3 w-3 text-amber" />
                    </span>
                    {item}
                  </li>
                ))}
                <li className="flex items-center gap-2.5 text-[13px] text-zinc-600">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-white/[0.03]">
                    <X className="h-3 w-3" />
                  </span>
                  No credit card required
                </li>
              </ul>

              <a
                href={site.support}
                target="_blank"
                rel="noreferrer"
                className="btn-primary relative mt-8 w-full"
              >
                Get premium
                <ArrowRight className="h-4 w-4" />
              </a>
              <p className="relative mt-3 text-center text-[10.5px] text-zinc-500">
                Redeem with <code className="font-mono text-amber/80">/premium redeem</code> in Discord.
              </p>
            </article>
          </Reveal>
        </div>

        <Reveal delay={120}>
          <p className="mt-6 text-center text-[12px] text-zinc-600">
            Looking for something custom?{' '}
            <Link href="/dashboard" className="text-zinc-400 underline decoration-white/20 underline-offset-4 hover:text-white">
              Open the dashboard
            </Link>{' '}
            or ask in the support server.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
