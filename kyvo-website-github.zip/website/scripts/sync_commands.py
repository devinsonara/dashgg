#!/usr/bin/env python3
"""Generate data/commands.json from the bot's real help definitions.

Reads MODULES / MERGED_CATEGORIES / CATEGORY_ORDER out of
cogs/commands/help.py without importing discord (AST only), then writes a
merged, website-friendly category list.

Usage:
    python3 scripts/sync_commands.py
    python3 scripts/sync_commands.py --help-file ../cogs/commands/help.py
"""
from __future__ import annotations

import argparse
import ast
import json
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_HELP = ROOT.parent / "cogs" / "commands" / "help.py"
OUT = ROOT / "data" / "commands.json"


class _BlankNames(ast.NodeTransformer):
    """Replace names such as EMOJI_SHIELD with a blank string so the literal
    can be evaluated without importing the bot's modules."""

    def visit_Name(self, node: ast.Name):  # noqa: N802
        return ast.copy_location(ast.Constant(value=""), node)


def _extract_assign(tree: ast.Module, name: str):
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    cloned = ast.parse(ast.unparse(node.value), mode="eval")
                    cloned = _BlankNames().visit(cloned)
                    ast.fix_missing_locations(cloned)
                    return ast.literal_eval(cloned)
    raise SystemExit(f"Could not find {name} in help.py")


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def build(path: Path) -> dict:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)

    modules = _extract_assign(tree, "MODULES")
    merged = _extract_assign(tree, "MERGED_CATEGORIES")
    order = _extract_assign(tree, "CATEGORY_ORDER")

    by_key = {m["key"]: m for m in modules}
    used: set[str] = set()
    categories: list[dict] = []

    for merge in merged:
        keys = [k for k in merge.get("keys", []) if k in by_key]
        if not keys:
            continue
        used.update(keys)
        primary = by_key[keys[0]]
        groups: list[dict] = []
        for key in keys:
            module = by_key[key]
            for label, commands in module.get("groups", []):
                title = label if len(keys) == 1 else f"{module['name']} · {label}"
                groups.append({"name": title, "commands": list(commands)})

        info = primary.get("info", "")
        categories.append(
            {
                "id": _slug(merge["name"]),
                "name": merge["name"],
                "description": merge.get("desc", primary.get("desc", "")),
                "info": info,
                "accent": primary.get("accent", 0xFFB43C),
                "icon": primary.get("key", "general"),
                "premium": "premium" in keys or "💎" in info,
                "groups": groups,
            }
        )

    for module in modules:
        if module["key"] in used:
            continue
        info = module.get("info", "")
        categories.append(
            {
                "id": _slug(module["name"]),
                "name": module["name"],
                "description": module.get("desc", ""),
                "info": info,
                "accent": module.get("accent", 0xFFB43C),
                "icon": module.get("key", "general"),
                "premium": module["key"] == "premium" or "premium" in info.lower(),
                "groups": [
                    {"name": label, "commands": list(commands)}
                    for label, commands in module.get("groups", [])
                ],
            }
        )

    # Respect the bot's own category order, extras afterwards.
    ranked = {name: i for i, name in enumerate(order)}
    categories.sort(key=lambda c: ranked.get(c["name"], len(ranked)))

    total = len({c for cat in categories for g in cat["groups"] for c in g["commands"]})
    for cat in categories:
        cat["count"] = len({c for g in cat["groups"] for c in g["commands"]})

    return {
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "totalCommands": total,
        "categories": categories,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--help-file", type=Path, default=DEFAULT_HELP)
    args = parser.parse_args()

    if not args.help_file.exists():
        raise SystemExit(f"help.py not found at {args.help_file}")

    data = build(args.help_file)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(
        f"Wrote {OUT.relative_to(ROOT)} — {len(data['categories'])} categories, "
        f"{data['totalCommands']} unique commands"
    )


if __name__ == "__main__":
    main()
